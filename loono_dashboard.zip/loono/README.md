# LOONO Dashboard — Guía de instalación

## Estructura
```
loono/
├── dashboard.php          ← Página principal (único archivo PHP de UI)
├── database.sql           ← Schema completo + datos demo
├── config/
│   └── db.php             ← Conexión PDO (editar credenciales aquí)
└── api/
    ├── juegos.php         ← CRUD completo de juegos
    ├── cursos.php         ← Cursos + actualización de progreso
    └── datos.php          ← Stats, tareas, logros, biblioteca, perfil
```

## Instalación (3 pasos)

### 1. Base de datos
```bash
mysql -u root -p < database.sql
# O importar database.sql desde phpMyAdmin
```

### 2. Credenciales
Editar `config/db.php`:
```php
define('DB_USER', 'tu_usuario');
define('DB_PASS', 'tu_password');
```

### 3. Servidor
Copiar carpeta `loono/` a `htdocs/` (XAMPP) o `www/` (Laragon):
```
http://localhost/loono/dashboard.php
```

---

## API Reference

### api/juegos.php
| Método | action | Parámetros | Descripción |
|--------|--------|-----------|-------------|
| GET | list | &cat= | Listar juegos (filtrar por categoría) |
| POST | add | titulo, url, descripcion, categoria, color, badge | Agregar juego |
| POST | edit | id + mismos campos | Editar juego |
| POST | toggle | id | Toggle favorito |
| POST | delete | id | Eliminar juego |

### api/cursos.php
| Método | action | Parámetros | Descripción |
|--------|--------|-----------|-------------|
| GET | list | — | Cursos + progreso del usuario |
| POST | update | curso_id, lecciones_hechas | Guardar progreso |

### api/datos.php
| action | Método | Descripción |
|--------|--------|-------------|
| stats | GET | Estadísticas + actualizar racha |
| tareas_list | GET | Listar tareas |
| tarea_add | POST | Nueva tarea |
| tarea_toggle | POST | Marcar/desmarcar completada |
| tarea_delete | POST | Eliminar tarea |
| logros | GET | Catálogo + estado desbloqueado |
| biblioteca | GET | Libros + estado leído |
| libro_toggle | POST | Marcar/desmarcar leído |
| perfil_get | GET | Obtener perfil completo |
| perfil_update | POST | Actualizar datos del perfil |
| change_password | POST | Cambiar contraseña |

---

## Tablas BD creadas

| Tabla | Propósito |
|-------|-----------|
| usuarios | Tu tabla existente |
| perfiles | Tu tabla existente + bio, nivel, xp_actual, xp_meta |
| estadisticas | Lecciones, estrellas, racha de días |
| cursos | Catálogo de cursos |
| progreso_cursos | Avance por usuario/curso |
| juegos | Juegos personalizados con links |
| tareas | Tareas con fecha límite |
| logros_catalogo | Catálogo de logros |
| logros_usuario | Logros desbloqueados |
| biblioteca | Catálogo de libros |
| biblioteca_leidos | Libros leídos por usuario |

## Integrar con tu sistema de login
En `config/db.php`, función `uid()`:
```php
function uid(): int {
    if (session_status()===PHP_SESSION_NONE) session_start();
    return (int)($_SESSION['usuario_id'] ?? 0);
}
```
Cuando el usuario inicia sesión en tu sistema, guarda:
```php
$_SESSION['usuario_id'] = $usuario['id'];
```
