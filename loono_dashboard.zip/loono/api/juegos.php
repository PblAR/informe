<?php
// api/juegos.php
// GET  ?action=list[&cat=matematicas]
// POST action=add    titulo url descripcion categoria color badge
// POST action=edit   id titulo url descripcion categoria color badge
// POST action=toggle id
// POST action=delete id
require_once __DIR__.'/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$uid    = uid();
$action = bodyStr('action') ?: ($_GET['action'] ?? 'list');

/* ── LIST ── */
if ($action === 'list') {
    $cat  = $_GET['cat'] ?? '';
    $sql  = "SELECT * FROM juegos WHERE usuario_id=?";
    $args = [$uid];
    if ($cat && $cat !== 'todos') { $sql .= " AND categoria=?"; $args[] = $cat; }
    $sql .= " ORDER BY favorito DESC, orden ASC, creado_en DESC";
    $st = db()->prepare($sql); $st->execute($args);
    jsonOut(['ok'=>true,'data'=>$st->fetchAll()]);
}

/* ── ADD ── */
if ($action === 'add') {
    $titulo = bodyStr('titulo'); $url = bodyStr('url');
    if (!$titulo || !$url) jsonOut(['ok'=>false,'error'=>'Título y URL son obligatorios'],400);
    if (!filter_var($url,FILTER_VALIDATE_URL)) jsonOut(['ok'=>false,'error'=>'URL no válida'],400);

    $cats   = ['matematicas','ciencias','lenguaje','arte','otro'];
    $colors = ['coral','blue','teal','purple','yellow'];
    $cat   = in_array(bodyStr('categoria'),$cats)  ? bodyStr('categoria') : 'otro';
    $color = in_array(bodyStr('color'),$colors)    ? bodyStr('color')     : 'teal';

    $maxOrd = db()->prepare("SELECT COALESCE(MAX(orden),0)+1 FROM juegos WHERE usuario_id=?");
    $maxOrd->execute([$uid]);
    $orden = (int)$maxOrd->fetchColumn();

    $st = db()->prepare("INSERT INTO juegos(usuario_id,titulo,url,descripcion,categoria,color,badge,favorito,orden)
                          VALUES(?,?,?,?,?,?,?,0,?)");
    $st->execute([$uid,$titulo,$url,bodyStr('descripcion'),$cat,$color,bodyStr('badge'),$orden]);
    $id = db()->lastInsertId();
    $row = db()->prepare("SELECT * FROM juegos WHERE id=?"); $row->execute([$id]);
    jsonOut(['ok'=>true,'data'=>$row->fetch()]);
}

/* ── EDIT ── */
if ($action === 'edit') {
    $id = bodyInt('id');
    $titulo = bodyStr('titulo'); $url = bodyStr('url');
    if (!$titulo || !$url) jsonOut(['ok'=>false,'error'=>'Título y URL son obligatorios'],400);
    if (!filter_var($url,FILTER_VALIDATE_URL)) jsonOut(['ok'=>false,'error'=>'URL no válida'],400);

    $cats   = ['matematicas','ciencias','lenguaje','arte','otro'];
    $colors = ['coral','blue','teal','purple','yellow'];
    $cat   = in_array(bodyStr('categoria'),$cats)  ? bodyStr('categoria') : 'otro';
    $color = in_array(bodyStr('color'),$colors)    ? bodyStr('color')     : 'teal';

    $st = db()->prepare("UPDATE juegos SET titulo=?,url=?,descripcion=?,categoria=?,color=?,badge=?
                          WHERE id=? AND usuario_id=?");
    $st->execute([$titulo,$url,bodyStr('descripcion'),$cat,$color,bodyStr('badge'),$id,$uid]);
    jsonOut(['ok'=>true]);
}

/* ── TOGGLE FAVORITO ── */
if ($action === 'toggle') {
    $id = bodyInt('id');
    db()->prepare("UPDATE juegos SET favorito=1-favorito WHERE id=? AND usuario_id=?")->execute([$id,$uid]);
    $r = db()->prepare("SELECT favorito FROM juegos WHERE id=?"); $r->execute([$id]);
    jsonOut(['ok'=>true,'favorito'=>(int)$r->fetchColumn()]);
}

/* ── DELETE ── */
if ($action === 'delete') {
    db()->prepare("DELETE FROM juegos WHERE id=? AND usuario_id=?")->execute([bodyInt('id'),$uid]);
    jsonOut(['ok'=>true]);
}

jsonOut(['ok'=>false,'error'=>'Acción desconocida'],400);
