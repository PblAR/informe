<?php
// api/cursos.php
// GET  ?action=list
// POST action=update  curso_id  lecciones_hechas
require_once __DIR__.'/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$uid    = uid();
$action = bodyStr('action') ?: ($_GET['action'] ?? 'list');

/* ── LIST ── */
if ($action === 'list') {
    $st = db()->prepare("
        SELECT c.*,
               COALESCE(pc.lecciones_hechas,0) AS lecciones_hechas,
               COALESCE(pc.porcentaje,0)        AS porcentaje
        FROM   cursos c
        LEFT JOIN progreso_cursos pc ON pc.curso_id=c.id AND pc.usuario_id=?
        WHERE  c.activo=1
        ORDER  BY c.orden ASC
    ");
    $st->execute([$uid]);
    jsonOut(['ok'=>true,'data'=>$st->fetchAll()]);
}

/* ── UPDATE ── */
if ($action === 'update') {
    $curso_id = bodyInt('curso_id');
    $hechas   = bodyInt('lecciones_hechas');

    $cs = db()->prepare("SELECT total_lecciones FROM cursos WHERE id=? AND activo=1");
    $cs->execute([$curso_id]);
    $curso = $cs->fetch();
    if (!$curso) jsonOut(['ok'=>false,'error'=>'Curso no encontrado'],404);

    $total   = (int)$curso['total_lecciones'];
    $hechas  = max(0, min($hechas, $total));
    $pct     = $total > 0 ? (int)round($hechas/$total*100) : 0;

    // Upsert progreso
    db()->prepare("
        INSERT INTO progreso_cursos(usuario_id,curso_id,lecciones_hechas,porcentaje)
        VALUES(?,?,?,?)
        ON DUPLICATE KEY UPDATE
            lecciones_hechas=VALUES(lecciones_hechas),
            porcentaje=VALUES(porcentaje),
            ultima_actividad=NOW()
    ")->execute([$uid,$curso_id,$hechas,$pct]);

    // Recalcular total de lecciones en estadísticas
    $tot = db()->prepare("SELECT SUM(lecciones_hechas) FROM progreso_cursos WHERE usuario_id=?");
    $tot->execute([$uid]); $totalL = (int)$tot->fetchColumn();
    db()->prepare("UPDATE estadisticas SET lecciones_completadas=? WHERE usuario_id=?")->execute([$totalL,$uid]);

    // XP +10 por lección
    db()->prepare("UPDATE perfiles SET xp_actual=LEAST(xp_meta,xp_actual+10) WHERE usuario_id=?")->execute([$uid]);

    jsonOut(['ok'=>true,'porcentaje'=>$pct,'lecciones_hechas'=>$hechas,'total'=>$total]);
}

jsonOut(['ok'=>false,'error'=>'Acción desconocida'],400);
