<?php
// api/datos.php  — Stats | Tareas | Logros | Biblioteca | Perfil
require_once __DIR__.'/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$uid    = uid();
$action = bodyStr('action') ?: ($_GET['action'] ?? '');

// ─────────────── ESTADÍSTICAS ───────────────
if ($action === 'stats') {
    // Actualizar racha
    $st = db()->prepare("SELECT ultimo_acceso,racha_dias,racha_max FROM estadisticas WHERE usuario_id=?");
    $st->execute([$uid]); $s = $st->fetch();
    if ($s) {
        $hoy=$hoje=date('Y-m-d'); $ayer=date('Y-m-d',strtotime('-1 day'));
        if ((string)$s['ultimo_acceso'] !== $hoy) {
            $racha    = ((string)$s['ultimo_acceso']===$ayer) ? $s['racha_dias']+1 : 1;
            $rachaMax = max($racha,(int)$s['racha_max']);
            db()->prepare("UPDATE estadisticas SET racha_dias=?,racha_max=?,ultimo_acceso=? WHERE usuario_id=?")
                ->execute([$racha,$rachaMax,$hoy,$uid]);
        }
    }
    $st2 = db()->prepare("
        SELECT e.*,p.nombre,p.apellido,p.nivel,p.xp_actual,p.xp_meta,
               p.nombre_avatar,p.rol,p.bio,p.whatsapp
        FROM estadisticas e
        JOIN perfiles p ON p.usuario_id=e.usuario_id
        WHERE e.usuario_id=?
    ");
    $st2->execute([$uid]);
    jsonOut(['ok'=>true,'data'=>$st2->fetch()]);
}

// ─────────────── TAREAS ───────────────
if ($action === 'tareas_list') {
    $st = db()->prepare("SELECT * FROM tareas WHERE usuario_id=?
                         ORDER BY completada ASC,fecha_limite ASC,creado_en DESC");
    $st->execute([$uid]);
    jsonOut(['ok'=>true,'data'=>$st->fetchAll()]);
}

if ($action === 'tarea_add') {
    $titulo = bodyStr('titulo');
    if (!$titulo) jsonOut(['ok'=>false,'error'=>'Título requerido'],400);
    $fl = bodyStr('fecha_limite') ?: null;
    $st = db()->prepare("INSERT INTO tareas(usuario_id,titulo,materia,fecha_limite) VALUES(?,?,?,?)");
    $st->execute([$uid,$titulo,bodyStr('materia'),$fl]);
    $id = db()->lastInsertId();
    $row = db()->prepare("SELECT * FROM tareas WHERE id=?"); $row->execute([$id]);
    jsonOut(['ok'=>true,'data'=>$row->fetch()]);
}

if ($action === 'tarea_toggle') {
    $id = bodyInt('id');
    db()->prepare("UPDATE tareas SET completada=1-completada WHERE id=? AND usuario_id=?")->execute([$id,$uid]);
    $r = db()->prepare("SELECT completada FROM tareas WHERE id=?"); $r->execute([$id]);
    $done = (int)$r->fetchColumn();
    if ($done) {
        db()->prepare("UPDATE estadisticas SET estrellas_ganadas=estrellas_ganadas+5 WHERE usuario_id=?")->execute([$uid]);
        db()->prepare("UPDATE perfiles SET xp_actual=LEAST(xp_meta,xp_actual+5) WHERE usuario_id=?")->execute([$uid]);
    }
    jsonOut(['ok'=>true,'completada'=>$done]);
}

if ($action === 'tarea_delete') {
    db()->prepare("DELETE FROM tareas WHERE id=? AND usuario_id=?")->execute([bodyInt('id'),$uid]);
    jsonOut(['ok'=>true]);
}

// ─────────────── LOGROS ───────────────
if ($action === 'logros') {
    $st = db()->prepare("
        SELECT lc.*,
               IF(lu.logro_id IS NULL,0,1) AS desbloqueado,
               lu.desbloqueado_en
        FROM   logros_catalogo lc
        LEFT JOIN logros_usuario lu ON lu.logro_id=lc.id AND lu.usuario_id=?
        ORDER  BY lc.id ASC
    ");
    $st->execute([$uid]);
    jsonOut(['ok'=>true,'data'=>$st->fetchAll()]);
}

// ─────────────── BIBLIOTECA ───────────────
if ($action === 'biblioteca') {
    $st = db()->prepare("
        SELECT b.*, IF(bl.libro_id IS NULL,0,1) AS leido
        FROM   biblioteca b
        LEFT JOIN biblioteca_leidos bl ON bl.libro_id=b.id AND bl.usuario_id=?
        WHERE  b.activo=1 ORDER BY b.id ASC
    ");
    $st->execute([$uid]);
    jsonOut(['ok'=>true,'data'=>$st->fetchAll()]);
}

if ($action === 'libro_toggle') {
    $id = bodyInt('id');
    $chk = db()->prepare("SELECT id FROM biblioteca_leidos WHERE usuario_id=? AND libro_id=?");
    $chk->execute([$uid,$id]);
    if ($chk->fetch()) {
        db()->prepare("DELETE FROM biblioteca_leidos WHERE usuario_id=? AND libro_id=?")->execute([$uid,$id]);
        jsonOut(['ok'=>true,'leido'=>0]);
    } else {
        db()->prepare("INSERT IGNORE INTO biblioteca_leidos(usuario_id,libro_id) VALUES(?,?)")->execute([$uid,$id]);
        db()->prepare("UPDATE estadisticas SET estrellas_ganadas=estrellas_ganadas+10 WHERE usuario_id=?")->execute([$uid]);
        jsonOut(['ok'=>true,'leido'=>1]);
    }
}

// ─────────────── PERFIL — GET ───────────────
if ($action === 'perfil_get') {
    $st = db()->prepare("SELECT p.*,u.email FROM perfiles p
                         JOIN usuarios u ON u.id=p.usuario_id
                         WHERE p.usuario_id=?");
    $st->execute([$uid]);
    $p = $st->fetch();
    if (!$p) jsonOut(['ok'=>false,'error'=>'Perfil no encontrado'],404);
    jsonOut(['ok'=>true,'data'=>$p]);
}

// ─────────────── PERFIL — UPDATE ───────────────
if ($action === 'perfil_update') {
    $nombre = bodyStr('nombre');
    if (!$nombre) jsonOut(['ok'=>false,'error'=>'El nombre es obligatorio'],400);
    $fn = bodyStr('fecha_nacimiento') ?: null;
    db()->prepare("
        INSERT INTO perfiles(usuario_id,nombre,apellido,rol,whatsapp,nombre_avatar,fecha_nacimiento,bio)
        VALUES(?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
            nombre=VALUES(nombre),apellido=VALUES(apellido),rol=VALUES(rol),
            whatsapp=VALUES(whatsapp),nombre_avatar=VALUES(nombre_avatar),
            fecha_nacimiento=VALUES(fecha_nacimiento),bio=VALUES(bio)
    ")->execute([$uid,$nombre,bodyStr('apellido'),bodyStr('rol'),
                 bodyStr('whatsapp'),bodyStr('nombre_avatar'),$fn,bodyStr('bio')]);
    jsonOut(['ok'=>true,'msg'=>'Perfil actualizado']);
}

// ─────────────── CAMBIAR PASSWORD ───────────────
if ($action === 'change_password') {
    $actual    = $_POST['password_actual']    ?? '';
    $nueva     = $_POST['password_nueva']     ?? '';
    $confirmar = $_POST['password_confirmar'] ?? '';
    if (strlen($nueva) < 6) jsonOut(['ok'=>false,'error'=>'Mínimo 6 caracteres'],400);
    if ($nueva !== $confirmar) jsonOut(['ok'=>false,'error'=>'Las contraseñas no coinciden'],400);
    $row = db()->prepare("SELECT password FROM usuarios WHERE id=?"); $row->execute([$uid]);
    $u = $row->fetch();
    if (!$u || !password_verify($actual,$u['password']))
        jsonOut(['ok'=>false,'error'=>'Contraseña actual incorrecta'],401);
    db()->prepare("UPDATE usuarios SET password=? WHERE id=?")
        ->execute([password_hash($nueva,PASSWORD_DEFAULT),$uid]);
    jsonOut(['ok'=>true,'msg'=>'Contraseña actualizada']);
}

jsonOut(['ok'=>false,'error'=>'Acción desconocida'],400);
