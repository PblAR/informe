<?php
// config/db.php — Conexión PDO + helpers globales
// ================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'NZ1');
define('DB_USER', 'root');     // ← CAMBIAR
define('DB_PASS', '');          // ← CAMBIAR

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $pdo = new PDO(
            "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
             PDO::ATTR_EMULATE_PREPARES   => false]
        );
    } catch (PDOException $e) {
        jsonOut(['ok'=>false,'error'=>'DB: '.$e->getMessage()], 500);
    }
    return $pdo;
}

function jsonOut(array $d, int $code=200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($d, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}

function uid(): int {
    if (session_status()===PHP_SESSION_NONE) session_start();
    return (int)($_SESSION['usuario_id'] ?? 1); // 1 = demo
}

function bodyInt(string $k, int $def=0): int {
    $src = $_SERVER['REQUEST_METHOD']==='POST' ? $_POST : $_GET;
    return isset($src[$k]) ? (int)$src[$k] : $def;
}

function bodyStr(string $k, string $def=''): string {
    $src = $_SERVER['REQUEST_METHOD']==='POST' ? $_POST : $_GET;
    return isset($src[$k]) ? trim((string)$src[$k]) : $def;
}
