-- ================================================================
--  LOONO — Base de datos NZ1
--  Ejecutar: mysql -u root -p < database.sql
-- ================================================================

CREATE DATABASE IF NOT EXISTS NZ1
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE NZ1;

-- ─────────────────────────────────────────────
--  1. USUARIOS  (tu tabla existente)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usuarios (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(100)  NOT NULL,
    email          VARCHAR(100)  UNIQUE NOT NULL,
    password       VARCHAR(255)  NOT NULL,
    fecha_registro TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
--  2. PERFILES  (tu tabla existente + campos extra)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS perfiles (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id       INT UNIQUE NOT NULL,
    nombre           VARCHAR(100) NOT NULL,
    apellido         VARCHAR(100),
    rol              VARCHAR(50),
    whatsapp         VARCHAR(20),
    nombre_avatar    VARCHAR(50)  DEFAULT 'nino1',
    fecha_nacimiento DATE,
    -- Nuevos
    bio              TEXT,
    nivel            TINYINT UNSIGNED DEFAULT 1,
    xp_actual        INT UNSIGNED     DEFAULT 0,
    xp_meta          INT UNSIGNED     DEFAULT 1000,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
--  3. ESTADÍSTICAS  (racha, estrellas, lecciones)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS estadisticas (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id            INT UNIQUE NOT NULL,
    lecciones_completadas INT UNSIGNED DEFAULT 0,
    estrellas_ganadas     INT UNSIGNED DEFAULT 0,
    racha_dias            INT UNSIGNED DEFAULT 0,
    racha_max             INT UNSIGNED DEFAULT 0,
    ultimo_acceso         DATE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
--  4. CURSOS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cursos (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    slug             VARCHAR(80)  UNIQUE NOT NULL,
    titulo           VARCHAR(150) NOT NULL,
    descripcion      TEXT,
    icono_color      ENUM('coral','blue','yellow','green') DEFAULT 'coral',
    categoria        VARCHAR(60),
    total_lecciones  TINYINT UNSIGNED DEFAULT 10,
    activo           TINYINT(1)   DEFAULT 1,
    orden            TINYINT UNSIGNED DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS progreso_cursos (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id        INT NOT NULL,
    curso_id          INT NOT NULL,
    lecciones_hechas  TINYINT UNSIGNED DEFAULT 0,
    porcentaje        TINYINT UNSIGNED DEFAULT 0,
    ultima_actividad  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_uc (usuario_id, curso_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (curso_id)   REFERENCES cursos(id)   ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
--  5. JUEGOS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS juegos (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id  INT NOT NULL,
    titulo      VARCHAR(150) NOT NULL,
    url         VARCHAR(500) NOT NULL,
    descripcion TEXT,
    categoria   ENUM('matematicas','ciencias','lenguaje','arte','otro') DEFAULT 'otro',
    color       ENUM('coral','blue','teal','purple','yellow')           DEFAULT 'teal',
    badge       VARCHAR(30)  DEFAULT '',
    favorito    TINYINT(1)   DEFAULT 0,
    orden       SMALLINT     DEFAULT 0,
    creado_en   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
--  6. TAREAS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tareas (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id   INT NOT NULL,
    titulo       VARCHAR(200) NOT NULL,
    materia      VARCHAR(100),
    fecha_limite DATE,
    completada   TINYINT(1)   DEFAULT 0,
    creado_en    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
--  7. LOGROS
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS logros_catalogo (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    slug          VARCHAR(80)  UNIQUE NOT NULL,
    titulo        VARCHAR(100) NOT NULL,
    descripcion   VARCHAR(220),
    emoji         VARCHAR(10),
    color_fondo   VARCHAR(20)  DEFAULT '#FFFBE6',
    xp_recompensa SMALLINT UNSIGNED DEFAULT 50
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS logros_usuario (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id      INT NOT NULL,
    logro_id        INT NOT NULL,
    desbloqueado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ul (usuario_id, logro_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (logro_id)   REFERENCES logros_catalogo(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
--  8. BIBLIOTECA
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS biblioteca (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    titulo      VARCHAR(150) NOT NULL,
    materia     VARCHAR(80),
    emoji       VARCHAR(10),
    color_fondo VARCHAR(20)  DEFAULT '#EEF4FF',
    nivel_texto VARCHAR(20)  DEFAULT 'Nivel 1',
    activo      TINYINT(1)   DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS biblioteca_leidos (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    libro_id   INT NOT NULL,
    leido_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ubk (usuario_id, libro_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (libro_id)   REFERENCES biblioteca(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ================================================================
--  DATOS DEMO
-- ================================================================

-- Usuario demo (password: demo1234)
INSERT IGNORE INTO usuarios (id, nombre, email, password)
VALUES (1, 'Mateo García', 'mateo@loono.com',
        '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

INSERT IGNORE INTO perfiles
  (usuario_id, nombre, apellido, rol, nombre_avatar, nivel, xp_actual, xp_meta, bio)
VALUES
  (1,'Mateo','García','Estudiante','nino1',5,620,1000,'¡Me encanta aprender cosas nuevas cada día!');

INSERT IGNORE INTO estadisticas
  (usuario_id, lecciones_completadas, estrellas_ganadas, racha_dias, ultimo_acceso)
VALUES (1, 24, 1240, 7, CURDATE());

-- Cursos
INSERT IGNORE INTO cursos (slug, titulo, descripcion, icono_color, categoria, total_lecciones, orden) VALUES
('matematicas',  'Matemáticas Divertidas', 'Suma, resta, multiplicación y más con actividades interactivas.','coral',  'matematicas', 20, 1),
('ciencias',     'Ciencias del Mundo',     'Explora la naturaleza, animales y el universo que te rodea.',   'blue',   'ciencias',    15, 2),
('arte',         'Arte y Creatividad',     'Pinta, dibuja y crea tu propio mundo lleno de colores.',        'yellow', 'arte',        12, 3),
('lectura',      'Lectura Mágica',         'Mejora tu lectura con cuentos y aventuras increíbles.',         'green',  'lenguaje',    18, 4);

INSERT IGNORE INTO progreso_cursos (usuario_id, curso_id, lecciones_hechas, porcentaje) VALUES
(1,1,15,75),(1,2,7,47),(1,3,11,92),(1,4,5,28);

-- Juegos demo
INSERT IGNORE INTO juegos (usuario_id, titulo, url, descripcion, categoria, color, badge, favorito, orden) VALUES
(1,'Suma Aventura',      'https://www.coolmathgames.com',   'Practica sumas con niveles emocionantes.',         'matematicas','coral', 'Nuevo',  0,1),
(1,'Explora el Universo','https://spaceplace.nasa.gov/es/', 'Aprende sobre planetas y estrellas del cosmos.',    'ciencias',   'blue',  '',       1,2),
(1,'Palabras Mágicas',   'https://www.starfall.com',        'Mejora tu vocabulario y ortografía jugando.',       'lenguaje',   'purple','Popular',0,3),
(1,'Colorea y Aprende',  'https://www.abcya.com',           'Arte mientras aprendes sobre colores y formas.',    'arte',       'yellow','',       0,4),
(1,'Tablas Express',     'https://www.mathplayground.com',  'Domina las tablas de multiplicar con diversión.',   'matematicas','teal',  '',       0,5);

-- Tareas demo
INSERT IGNORE INTO tareas (usuario_id, titulo, materia, fecha_limite, completada) VALUES
(1,'Ejercicio de multiplicación','Matemáticas · Lección 7', CURDATE(),                           1),
(1,'Leer capítulo 3',            'Lectura Mágica',           CURDATE(),                           0),
(1,'Dibujo: Mi animal favorito', 'Arte y Creatividad',       DATE_ADD(CURDATE(),INTERVAL 1 DAY),  0),
(1,'Video: El sistema solar',    'Ciencias del Mundo',       DATE_ADD(CURDATE(),INTERVAL 1 DAY),  0),
(1,'Quiz de vocabulario',        'Palabras Mágicas Nivel 4', DATE_ADD(CURDATE(),INTERVAL 2 DAY),  1),
(1,'Experimento: Volcán',        'Ciencias del Mundo',       DATE_ADD(CURDATE(),INTERVAL 3 DAY),  0);

-- Catálogo logros
INSERT IGNORE INTO logros_catalogo (slug,titulo,descripcion,emoji,color_fondo,xp_recompensa) VALUES
('primera-leccion',   'Primera lección',     'Completaste tu primera lección',       '⭐','#FFFBE6',50),
('racha-7',           'Racha de 7 días',     '7 días seguidos aprendiendo',          '🔥','#FFF0EE',150),
('super-lector',      'Súper lector',        'Leer 5 libros completos',              '🏆','#EEF4FF',200),
('cientifico-junior', 'Científico junior',   'Completa 10 experimentos',             '🧪','#F0FFF4',100),
('artista',           'Artista creativo',    'Crea 20 obras de arte',                '🎨','#F3ECFF',120),
('maestro-mate',      'Maestro matemático',  '100% en tablas de multiplicar',        '🔢','#FFF0EE',300),
('explorador',        'Explorador del mundo','Completa el curso de Ciencias',        '🌍','#EEF4FF',250),
('devorador',         'Devorador de libros', 'Lee 20 libros en la biblioteca',       '📚','#F3ECFF',400);

INSERT IGNORE INTO logros_usuario (usuario_id,logro_id) VALUES (1,1),(1,2),(1,3),(1,4),(1,5);

-- Biblioteca
INSERT IGNORE INTO biblioteca (titulo,materia,emoji,color_fondo,nivel_texto) VALUES
('El rey de la selva', 'Lectura', '🦁','#FFF0EE','Nivel 1'),
('Viaje al espacio',   'Ciencias','🚀','#EEF4FF','Nivel 2'),
('El dragón amigable', 'Lectura', '🐉','#F3ECFF','Nivel 2'),
('Océanos profundos',  'Ciencias','🌊','#E0F7F6','Nivel 3'),
('La música del mundo','Arte',    '🎵','#FFFBE6','Nivel 1'),
('Metamorfosis',       'Ciencias','🦋','#F0FFF4','Nivel 2');

INSERT IGNORE INTO biblioteca_leidos (usuario_id,libro_id) VALUES (1,1),(1,3);
