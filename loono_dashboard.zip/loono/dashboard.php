<?php
require_once __DIR__.'/config/db.php';
$uid = uid();
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Loono — Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=Fredoka+One&display=swap" rel="stylesheet">
<style>
/* ═══════════════════ VARIABLES ═══════════════════ */
:root{
  --teal:#4ECDC4;--tl:#A8EDEA;--tld:#2CB5AC;
  --coral:#FF6B5E;--orange:#FF9F43;--yellow:#FFD93D;
  --green:#6BCB77;--blue:#4D96FF;--purple:#C77DFF;
  --white:#fff;--bg:#E8FAF9;
  --dk:#2D3436;--md:#636E72;--lt:#b2bec3;
  --sh:0 6px 28px rgba(0,0,0,.08);
  --shh:0 14px 40px rgba(0,0,0,.14);
  --r:20px;--rs:12px;
  --hh:64px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:'Nunito',sans-serif;background:var(--bg);color:var(--dk);min-height:100vh;overflow-x:hidden}
button,input,select,textarea{font-family:'Nunito',sans-serif}
a{text-decoration:none;color:inherit}
img{display:block;max-width:100%}

/* ═══════════════════ HEADER ═══════════════════ */
header{
  background:var(--white);height:var(--hh);
  display:flex;align-items:center;justify-content:space-between;
  padding:0 32px;box-shadow:0 2px 16px rgba(0,0,0,.07);
  position:sticky;top:0;z-index:200;gap:16px;
}
.logo{font-family:'Fredoka One',cursive;font-size:26px;color:var(--coral);letter-spacing:1px;flex-shrink:0}
.logo span{color:var(--teal)}
.nav-d{display:flex;gap:2px;flex:1;justify-content:center}
.nl{display:flex;align-items:center;gap:6px;padding:8px 12px;border-radius:var(--rs);
    color:var(--md);font-size:12.5px;font-weight:700;border:none;background:none;
    cursor:pointer;transition:background .18s,color .18s;white-space:nowrap}
.nl svg{width:15px;height:15px;flex-shrink:0}
.nl:hover,.nl.active{background:var(--tl);color:var(--teal)}
.hamburger{display:none;width:40px;height:40px;border:none;background:var(--bg);
           border-radius:var(--rs);align-items:center;justify-content:center;
           flex-shrink:0;cursor:pointer;transition:background .2s}
.hamburger:hover{background:var(--tl)}
.hamburger svg{width:22px;height:22px}
/* Drawer móvil */
.drawer{display:none;position:fixed;inset:0;z-index:300}
.drawer.open{display:flex}
.drawer-bg{position:absolute;inset:0;background:rgba(0,0,0,.32)}
.drawer-panel{
  position:relative;z-index:1;background:var(--white);
  width:272px;height:100%;padding:20px 14px;
  display:flex;flex-direction:column;gap:4px;
  box-shadow:4px 0 24px rgba(0,0,0,.14);
  animation:slideIn .24s ease;
}
@keyframes slideIn{from{transform:translateX(-100%)}to{transform:translateX(0)}}
.drawer-head{display:flex;justify-content:space-between;align-items:center;
             margin-bottom:16px;padding-bottom:14px;border-bottom:2px solid var(--bg)}
.drawer-close{width:34px;height:34px;border:none;background:var(--bg);border-radius:50%;
              display:flex;align-items:center;justify-content:center;cursor:pointer}
.drawer-close svg{width:17px;height:17px}
.mnl{display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:var(--rs);
     color:var(--md);font-size:14px;font-weight:700;border:none;background:none;
     cursor:pointer;transition:background .18s,color .18s;width:100%;text-align:left}
.mnl svg{width:18px;height:18px;flex-shrink:0}
.mnl:hover,.mnl.active{background:var(--tl);color:var(--teal)}
/* Header right */
.h-right{display:flex;gap:6px;align-items:center;flex-shrink:0}
.icon-btn{width:38px;height:38px;border-radius:50%;border:none;background:var(--bg);
          display:flex;align-items:center;justify-content:center;
          cursor:pointer;transition:transform .2s,background .2s;position:relative}
.icon-btn svg{width:19px;height:19px}
.icon-btn:hover{transform:scale(1.1);background:var(--tl)}
.nb::after{content:'';position:absolute;top:6px;right:6px;width:7px;height:7px;
           background:var(--coral);border-radius:50%;border:2px solid white}
.av-mini{width:38px;height:38px;border-radius:50%;
         background:linear-gradient(135deg,var(--teal),var(--blue));
         display:flex;align-items:center;justify-content:center;
         cursor:pointer;border:2px solid var(--tl);transition:transform .2s;flex-shrink:0}
.av-mini:hover{transform:scale(1.08)}
.av-mini svg{width:22px;height:22px}

/* ═══════════════════ HERO ═══════════════════ */
.hero{
  background:linear-gradient(135deg,#fff 0%,#c8f5f2 55%,#b2efe9 100%);
  padding:44px 48px 0;position:relative;overflow:hidden;
  min-height:340px;display:flex;align-items:flex-end;
}
.paisaje{
  position:absolute;right:0;bottom:0;width:60%;height:100%;
  background-image:url('https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=900&q=80');
  background-size:cover;background-position:center;
  -webkit-mask-image:linear-gradient(to right,transparent 0%,rgba(0,0,0,.15) 18%,black 42%);
  mask-image:linear-gradient(to right,transparent 0%,rgba(0,0,0,.15) 18%,black 42%);
}
.hero-wave{position:absolute;bottom:0;left:0;right:0;height:50px;z-index:3}
.hero-text{max-width:420px;padding-bottom:64px;z-index:4;position:relative;animation:fadeUp .6s ease both}
.hero-badge{display:inline-flex;align-items:center;gap:6px;
            background:rgba(78,205,196,.15);border:1.5px solid var(--teal);color:var(--teal);
            border-radius:30px;padding:5px 14px;font-size:12px;font-weight:800;margin-bottom:14px}
.hero-badge svg{width:13px;height:13px}
.hero-text h1{font-family:'Fredoka One',cursive;font-size:40px;color:var(--dk);line-height:1.1;margin-bottom:12px}
.hero-text h1 .cc{color:var(--coral)}.hero-text h1 .ct{color:var(--teal)}
.hero-text p{font-size:13.5px;color:var(--md);line-height:1.7;margin-bottom:24px;max-width:340px}
.hero-btns{display:flex;gap:12px;flex-wrap:wrap}
.btn-pr{background:var(--coral);color:white;border:none;border-radius:30px;
        padding:12px 28px;font-weight:800;font-size:14px;cursor:pointer;
        box-shadow:0 6px 18px rgba(255,107,94,.38);
        transition:transform .2s,box-shadow .2s;display:inline-flex;align-items:center;gap:8px}
.btn-pr svg{width:17px;height:17px}
.btn-pr:hover{transform:translateY(-3px);box-shadow:0 10px 24px rgba(255,107,94,.48)}
.btn-gh{background:none;border:2px solid rgba(0,0,0,.12);color:var(--md);
        border-radius:30px;padding:10px 20px;font-weight:800;font-size:13.5px;
        cursor:pointer;transition:border-color .2s,color .2s;
        display:inline-flex;align-items:center;gap:7px}
.btn-gh svg{width:16px;height:16px}
.btn-gh:hover{border-color:var(--teal);color:var(--teal)}

/* ═══════════════════ TABS ═══════════════════ */
.tabs-bar{
  background:white;display:flex;align-items:center;
  padding:0 32px;box-shadow:0 2px 8px rgba(0,0,0,.05);
  overflow-x:auto;scrollbar-width:none;height:50px;
  position:sticky;top:var(--hh);z-index:150;
}
.tabs-bar::-webkit-scrollbar{display:none}
.tab-btn{background:none;border:none;padding:0 18px;height:100%;
         font-weight:700;font-size:13px;color:var(--md);cursor:pointer;
         border-bottom:3px solid transparent;transition:color .2s,border-color .2s;
         white-space:nowrap;display:flex;align-items:center;gap:7px;flex-shrink:0}
.tab-btn svg{width:15px;height:15px}
.tab-btn:hover{color:var(--teal)}
.tab-btn.active{color:var(--teal);border-bottom-color:var(--teal)}
.tab-sp{flex:1}
.btn-ol{background:none;border:2px solid var(--teal);color:var(--teal);
        border-radius:20px;padding:7px 18px;font-weight:800;font-size:12.5px;
        cursor:pointer;display:inline-flex;align-items:center;gap:6px;
        transition:background .2s,color .2s;flex-shrink:0}
.btn-ol svg{width:14px;height:14px}
.btn-ol:hover{background:var(--teal);color:white}

/* ═══════════════════ SECTIONS ═══════════════════ */
.sec{display:none}.sec.active{display:block}

/* ═══════════════════ LAYOUT ═══════════════════ */
.pg{display:grid;grid-template-columns:1fr 300px;gap:24px;
    padding:28px 32px;max-width:1380px;margin:0 auto}
.wrap{padding:28px 32px;max-width:1380px;margin:0 auto}
.sec-t{font-family:'Fredoka One',cursive;font-size:20px;color:var(--dk);
        margin-bottom:16px;display:flex;align-items:center;gap:8px}
.sec-t svg{width:21px;height:21px}
.sec-h{display:flex;align-items:center;justify-content:space-between;
        margin-bottom:20px;flex-wrap:wrap;gap:12px}
.sec-h .sec-t{margin-bottom:0}

/* ═══════════════════ STATS ═══════════════════ */
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:24px}
.stat-card{background:white;border-radius:var(--r);padding:18px 20px;
           display:flex;align-items:center;gap:14px;box-shadow:var(--sh);
           transition:transform .22s,box-shadow .22s;animation:fadeUp .45s ease both}
.stat-card:hover{transform:translateY(-4px);box-shadow:var(--shh)}
.stat-card:nth-child(1){animation-delay:.04s}
.stat-card:nth-child(2){animation-delay:.09s}
.stat-card:nth-child(3){animation-delay:.14s}
.stat-ic{width:48px;height:48px;border-radius:14px;
          display:flex;align-items:center;justify-content:center;flex-shrink:0}
.stat-ic svg{width:25px;height:25px}
.sic1{background:#FFF0EE}.sic2{background:#EEF4FF}.sic3{background:#F0FFF4}
.stat-info h3{font-size:22px;font-weight:900;color:var(--dk);line-height:1}
.stat-info p{font-size:11px;color:var(--md);font-weight:700;margin-top:3px}

/* ═══════════════════ CURSOS ═══════════════════ */
.courses-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px;margin-bottom:24px}
.cc{background:white;border-radius:var(--r);padding:22px;box-shadow:var(--sh);
    transition:transform .25s,box-shadow .25s;position:relative;overflow:hidden;
    animation:fadeUp .45s ease both}
.cc:hover{transform:translateY(-5px);box-shadow:var(--shh)}
.cc:nth-child(1){animation-delay:.08s}.cc:nth-child(2){animation-delay:.13s}
.cc:nth-child(3){animation-delay:.18s}.cc:nth-child(4){animation-delay:.23s}
.cc::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;
             border-radius:var(--r) var(--r) 0 0}
.cc-coral::before{background:var(--coral)}.cc-blue::before{background:var(--blue)}
.cc-yellow::before{background:var(--yellow)}.cc-green::before{background:var(--green)}
.cc-ic{width:42px;height:42px;border-radius:13px;
       display:flex;align-items:center;justify-content:center;margin-bottom:11px}
.cc-ic svg{width:24px;height:24px}
.ci-coral{background:#FFF0EE}.ci-blue{background:#EEF4FF}
.ci-yellow{background:#FFFBE6}.ci-green{background:#F0FFF4}
.cc h4{font-weight:800;font-size:14px;margin-bottom:5px}
.cc p{font-size:12px;color:var(--md);line-height:1.5;margin-bottom:12px}
.pb-wrap{background:#f0f0f0;border-radius:10px;height:7px;margin-bottom:5px;overflow:hidden}
.pb{height:100%;border-radius:10px;width:0;transition:width 1.1s cubic-bezier(.4,0,.2,1)}
.pb-coral{background:linear-gradient(90deg,#FF6B5E,#FF9F43)}
.pb-blue{background:linear-gradient(90deg,#4D96FF,#5ECDFF)}
.pb-yellow{background:linear-gradient(90deg,#FFD93D,#FFB800)}
.pb-green{background:linear-gradient(90deg,#6BCB77,#41B54A)}
.pb-pct{font-size:10.5px;color:var(--md);font-weight:800;margin-bottom:12px}
/* Stepper lecciones */
.stepper{display:flex;align-items:center;gap:8px;margin-bottom:12px}
.stepper button{width:30px;height:30px;border-radius:50%;border:none;
                font-size:18px;font-weight:900;cursor:pointer;
                display:flex;align-items:center;justify-content:center;transition:all .18s}
.stp-m{background:#f0f0f0;color:var(--md)}.stp-m:hover{background:#ddd}
.stp-p{background:var(--tl);color:var(--teal)}.stp-p:hover{background:var(--teal);color:white}
.stp-val{font-size:12px;font-weight:800;color:var(--dk);min-width:72px;text-align:center}
/* Botones */
.btn-sm{border:none;border-radius:14px;padding:8px 16px;font-weight:800;font-size:12px;
        cursor:pointer;transition:transform .18s,box-shadow .18s;
        display:inline-flex;align-items:center;gap:6px}
.btn-sm svg{width:12px;height:12px}
.btn-sm:hover{transform:scale(1.06);box-shadow:0 4px 14px rgba(0,0,0,.15)}
.bs-co{background:var(--coral);color:white}.bs-bl{background:var(--blue);color:white}
.bs-ye{background:var(--yellow);color:#5a4000}.bs-gr{background:var(--green);color:white}
.bs-te{background:var(--teal);color:white}.bs-pu{background:var(--purple);color:white}

/* ═══════════════════ FEATURES / CTA ═══════════════════ */
.feat-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:24px}
.feat-card{background:white;border-radius:var(--r);padding:20px 14px;text-align:center;
           box-shadow:var(--sh);cursor:pointer;
           transition:transform .22s,box-shadow .22s;animation:fadeUp .45s ease .28s both}
.feat-card:hover{transform:translateY(-5px);box-shadow:var(--shh)}
.feat-ic{width:54px;height:54px;border-radius:50%;margin:0 auto 12px;
          display:flex;align-items:center;justify-content:center}
.feat-ic svg{width:27px;height:27px}
.fc1{background:#FFF0EE}.fc2{background:#EEF4FF}.fc3{background:#F3ECFF}
.feat-card h5{font-weight:800;font-size:13.5px;margin-bottom:5px}
.feat-card p{font-size:11px;color:var(--md);line-height:1.5}
.cta-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.cta-card{border-radius:var(--r);padding:18px 20px;display:flex;align-items:center;
          gap:14px;cursor:pointer;transition:transform .22s,box-shadow .22s;
          border:none;text-align:left;animation:fadeUp .45s ease .32s both}
.cta-card:hover{transform:translateY(-4px);box-shadow:0 12px 32px rgba(0,0,0,.2)}
.cta-card.org{background:linear-gradient(135deg,var(--coral),#FF9B75);color:white}
.cta-card.tea{background:linear-gradient(135deg,var(--teal),#26C6BA);color:white}
.cta-iw{width:42px;height:42px;flex-shrink:0;background:rgba(255,255,255,.22);
         border-radius:13px;display:flex;align-items:center;justify-content:center}
.cta-iw svg{width:24px;height:24px}
.cta-tx h5{font-size:14px;font-weight:900;margin-bottom:2px}
.cta-tx p{font-size:11.5px;opacity:.88}

/* ═══════════════════ SIDEBAR ═══════════════════ */
.sidebar{display:flex;flex-direction:column;gap:18px}
.prof-card{background:white;border-radius:var(--r);padding:22px;
           box-shadow:var(--sh);text-align:center;animation:fadeUp .45s ease .05s both}
.av-lg{width:68px;height:68px;border-radius:50%;
       background:linear-gradient(135deg,var(--teal),var(--blue));
       margin:0 auto 12px;display:flex;align-items:center;justify-content:center;
       border:4px solid var(--tl)}
.av-lg svg{width:42px;height:42px}
.prof-card h4{font-weight:900;font-size:16px;margin-bottom:3px}
.prof-lv{font-size:11.5px;color:var(--md);font-weight:700;margin-bottom:14px;
          display:flex;align-items:center;justify-content:center;gap:5px}
.prof-lv svg{width:13px;height:13px}
.xp-wrap{background:#f0f0f0;border-radius:10px;height:8px;margin-bottom:5px;overflow:hidden}
.xp-bar{background:linear-gradient(90deg,var(--teal),var(--blue));
        width:0;height:100%;border-radius:10px;transition:width 1.3s cubic-bezier(.4,0,.2,1)}
.xp-lbl{font-size:10.5px;color:var(--md);font-weight:700;text-align:right;margin-bottom:14px}
.btn-full{width:100%;display:flex;align-items:center;justify-content:center;gap:7px}
.btn-full svg{width:14px;height:14px}
/* Calendar */
.cal-card{background:white;border-radius:var(--r);padding:20px;
          box-shadow:var(--sh);animation:fadeUp .45s ease .12s both}
.cal-hd{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.cal-hd h4{font-weight:800;font-size:14px;display:flex;align-items:center;gap:7px}
.cal-hd h4 svg{width:16px;height:16px}
.cal-nav{display:flex;gap:5px}
.cal-nav button{width:26px;height:26px;border-radius:50%;border:2px solid var(--bg);
                background:var(--bg);cursor:pointer;font-size:13px;font-weight:900;
                color:var(--md);transition:background .2s}
.cal-nav button:hover{background:var(--tl);color:var(--teal)}
.cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;text-align:center}
.dl{font-size:9px;font-weight:900;color:var(--md);padding:3px 0;text-transform:uppercase}
.day{font-size:11px;font-weight:700;padding:5px 2px;border-radius:7px;cursor:pointer;
     transition:background .18s}
.day:hover{background:var(--tl);color:var(--teal)}
.day.today{background:var(--coral);color:white}
.day.ev{position:relative}
.day.ev::after{content:'';width:4px;height:4px;background:var(--teal);border-radius:50%;
               position:absolute;bottom:1px;left:50%;transform:translateX(-50%)}
.day.emp{opacity:0;pointer-events:none}
/* Events */
.ev-card{background:white;border-radius:var(--r);padding:20px;
         box-shadow:var(--sh);animation:fadeUp .45s ease .18s both}
.ev-item{display:flex;align-items:center;gap:10px;padding:8px;
         border-radius:var(--rs);cursor:pointer;transition:background .15s;margin:0 -8px}
.ev-item:hover{background:var(--bg)}
.ev-dot{width:9px;height:9px;border-radius:50%;flex-shrink:0}
.ev-info{flex:1}
.ev-info h6{font-size:12.5px;font-weight:800}
.ev-info p{font-size:10.5px;color:var(--md)}
.ev-time{font-size:10.5px;font-weight:800;color:var(--md);white-space:nowrap}

/* ═══════════════════ JUEGOS ═══════════════════ */
.filter-chips{display:flex;gap:8px;flex-wrap:wrap}
.chip{border:2px solid #e0e0e0;background:white;border-radius:30px;padding:6px 16px;
      font-weight:700;font-size:12px;color:var(--md);cursor:pointer;transition:all .18s}
.chip:hover,.chip.active{background:var(--tl);border-color:var(--teal);color:var(--teal)}
.games-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:20px}
/* Game card */
.game-card{background:white;border-radius:var(--r);overflow:hidden;
           box-shadow:var(--sh);transition:transform .25s,box-shadow .25s;
           display:flex;flex-direction:column;position:relative}
.game-card:hover{transform:translateY(-6px);box-shadow:var(--shh)}
.gc-thumb{width:100%;height:150px;display:flex;align-items:center;justify-content:center;
          position:relative;overflow:hidden}
.gc-overlay{position:absolute;inset:0;background:rgba(0,0,0,.12)}
.gc-play{position:relative;z-index:1;width:52px;height:52px;border-radius:50%;
         border:none;background:rgba(255,255,255,.92);
         display:flex;align-items:center;justify-content:center;cursor:pointer;
         transition:transform .2s,box-shadow .2s;box-shadow:0 4px 14px rgba(0,0,0,.2)}
.gc-play:hover{transform:scale(1.12);box-shadow:0 6px 20px rgba(0,0,0,.28)}
.gc-play svg{width:22px;height:22px}
.gc-badge{position:absolute;top:10px;right:10px;z-index:2;
          background:var(--yellow);color:#5a4000;border-radius:20px;
          padding:3px 10px;font-size:10px;font-weight:900}
.gc-body{padding:16px 18px;flex:1;display:flex;flex-direction:column;gap:8px}
.gc-body h4{font-weight:900;font-size:14.5px}
.gc-body p{font-size:11.5px;color:var(--md);line-height:1.5;flex:1}
.gc-meta{display:flex;align-items:center;justify-content:space-between}
.gc-tag{background:var(--bg);border-radius:20px;padding:3px 10px;
        font-size:10.5px;font-weight:800;color:var(--teal)}
.gc-stars{display:flex;gap:2px}
.gc-stars svg{width:12px;height:12px}
.gc-foot{padding:0 18px 16px;display:flex;gap:8px}
.btn-play{flex:1;border:none;border-radius:14px;padding:9px;font-weight:800;font-size:12.5px;
          display:flex;align-items:center;justify-content:center;gap:6px;
          transition:transform .18s,box-shadow .18s;cursor:pointer}
.btn-play svg{width:13px;height:13px}
.btn-play:hover{transform:scale(1.04);box-shadow:0 4px 14px rgba(0,0,0,.15)}
.btn-ico{width:34px;height:34px;border-radius:10px;border:2px solid #f0f0f0;
         background:white;display:flex;align-items:center;justify-content:center;
         transition:all .18s;cursor:pointer;flex-shrink:0}
.btn-ico svg{width:15px;height:15px}
.btn-ico.fav-on{border-color:var(--coral);background:var(--coral)}
.btn-ico.fav-on svg{stroke:white}
.btn-ico:hover{border-color:var(--teal);background:var(--tl)}
.btn-ico.del:hover{border-color:var(--coral);background:#fff0ee}
.btn-ico.edit:hover{border-color:var(--blue);background:#EEF4FF}
/* Add card */
.add-card{background:white;border-radius:var(--r);border:3px dashed #d0ece9;
          display:flex;flex-direction:column;align-items:center;justify-content:center;
          gap:12px;min-height:280px;cursor:pointer;
          transition:border-color .2s,background .2s;color:var(--md);text-align:center;padding:24px}
.add-card:hover{border-color:var(--teal);background:#f0fdfc}
.add-ic{width:60px;height:60px;border-radius:50%;background:var(--tl);
         display:flex;align-items:center;justify-content:center}
.add-ic svg{width:28px;height:28px}
.add-card h4{font-weight:800;font-size:14.5px;color:var(--dk)}
.add-card p{font-size:12px;line-height:1.5}

/* ═══════════════════ TAREAS ═══════════════════ */
.tareas-list{display:flex;flex-direction:column;gap:12px;max-width:700px}
.ta-item{background:white;border-radius:var(--r);padding:18px 22px;
         box-shadow:var(--sh);display:flex;align-items:center;gap:14px;
         transition:transform .2s;animation:fadeUp .4s ease both}
.ta-item:hover{transform:translateX(4px)}
.ta-chk{width:24px;height:24px;border-radius:8px;border:2.5px solid #ddd;
        display:flex;align-items:center;justify-content:center;cursor:pointer;
        flex-shrink:0;transition:all .2s}
.ta-chk.done{background:var(--green);border-color:var(--green)}
.ta-chk svg{display:none;width:14px;height:14px}
.ta-chk.done svg{display:block}
.ta-info{flex:1}
.ta-info h5{font-weight:800;font-size:14px}
.ta-info p{font-size:12px;color:var(--md);margin-top:2px}
.ta-date{font-size:11px;font-weight:800;color:var(--md)}
.ta-item.done-i .ta-info h5{text-decoration:line-through;color:var(--lt)}
.ta-del{width:28px;height:28px;border-radius:8px;border:none;background:#f8f8f8;
        display:flex;align-items:center;justify-content:center;cursor:pointer;
        transition:background .18s;flex-shrink:0}
.ta-del:hover{background:#fff0ee}
.ta-del svg{width:14px;height:14px}

/* ═══════════════════ LOGROS ═══════════════════ */
.logros-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px}
.lo-card{background:white;border-radius:var(--r);padding:22px 16px;text-align:center;
         box-shadow:var(--sh);transition:transform .22s;animation:fadeUp .4s ease both}
.lo-card:hover{transform:translateY(-4px)}
.lo-card.locked{opacity:.5}
.lo-ic{width:60px;height:60px;border-radius:50%;margin:0 auto 12px;
       display:flex;align-items:center;justify-content:center;font-size:28px}
.lo-card h5{font-weight:800;font-size:13px;margin-bottom:4px}
.lo-card p{font-size:11px;color:var(--md)}
.badge-new{background:var(--coral);color:white;border-radius:20px;
           padding:2px 8px;font-size:9px;font-weight:900;display:inline-block;margin-top:6px}

/* ═══════════════════ BIBLIOTECA ═══════════════════ */
.bib-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px}
.bk-card{background:white;border-radius:var(--r);overflow:hidden;
         box-shadow:var(--sh);transition:transform .22s;cursor:pointer;
         animation:fadeUp .4s ease both}
.bk-card:hover{transform:translateY(-5px)}
.bk-cover{height:120px;display:flex;align-items:center;justify-content:center;
          font-size:48px;position:relative}
.bk-read{position:absolute;top:8px;right:8px;background:var(--green);
         color:white;border-radius:20px;padding:2px 8px;font-size:9px;font-weight:900}
.bk-info{padding:14px 16px}
.bk-info h5{font-weight:800;font-size:13px;margin-bottom:3px}
.bk-info p{font-size:11px;color:var(--md)}

/* ═══════════════════ PERFIL ═══════════════════ */
.perf-wrap{padding:28px 32px;max-width:860px;margin:0 auto}
.perf-card{background:white;border-radius:var(--r);padding:32px;
           box-shadow:var(--sh);animation:fadeUp .4s ease both}
.perf-top{display:flex;align-items:center;gap:24px;margin-bottom:28px;
          padding-bottom:24px;border-bottom:2px solid var(--bg);flex-wrap:wrap}
.perf-av{width:88px;height:88px;border-radius:50%;
         background:linear-gradient(135deg,var(--teal),var(--blue));
         display:flex;align-items:center;justify-content:center;
         border:4px solid var(--tl);flex-shrink:0}
.perf-av svg{width:54px;height:54px}
.perf-inf h2{font-family:'Fredoka One',cursive;font-size:22px;margin-bottom:4px}
.perf-inf p{font-size:13px;color:var(--md)}
.perf-xp{display:flex;align-items:center;gap:8px;margin-top:10px}
.perf-xp .xp-wrap{width:140px;margin:0}
.fs-t{font-family:'Fredoka One',cursive;font-size:17px;color:var(--dk);
       margin:0 0 16px;padding-bottom:8px;border-bottom:2px solid var(--bg)}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:8px}
.fg{display:flex;flex-direction:column;gap:6px}
.fg.full{grid-column:1/-1}
.fg label{font-size:12.5px;font-weight:800;color:var(--dk)}
.fg input,.fg select,.fg textarea{
  padding:10px 14px;border:2px solid #e8e8e8;border-radius:var(--rs);
  font-size:13px;font-weight:600;color:var(--dk);outline:none;
  transition:border-color .2s;background:white}
.fg input:focus,.fg select:focus,.fg textarea:focus{border-color:var(--teal)}
.fg textarea{resize:vertical;min-height:80px}
.form-act{display:flex;gap:12px;justify-content:flex-end;margin-top:20px}
.pwd-sec{margin-top:28px;padding-top:24px;border-top:2px solid var(--bg)}

/* ═══════════════════ PADRES ═══════════════════ */
.padres-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:18px}
.pad-card{background:white;border-radius:var(--r);padding:24px;
          box-shadow:var(--sh);animation:fadeUp .4s ease both}
.pad-ic{width:48px;height:48px;border-radius:14px;
        display:flex;align-items:center;justify-content:center;margin-bottom:12px}
.pad-ic svg{width:26px;height:26px}
.pad-card h4{font-weight:800;font-size:15px;margin-bottom:6px}
.pad-card p{font-size:12.5px;color:var(--md);line-height:1.6;margin-bottom:16px}

/* ═══════════════════ MODAL ═══════════════════ */
.modal-ov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.42);
          z-index:400;align-items:center;justify-content:center;padding:20px}
.modal-ov.open{display:flex}
.modal{background:white;border-radius:var(--r);padding:28px;width:100%;max-width:460px;
       box-shadow:0 20px 60px rgba(0,0,0,.2);animation:fadeUp .3s ease;
       max-height:90vh;overflow-y:auto}
.modal-hd{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
.modal-hd h3{font-family:'Fredoka One',cursive;font-size:20px}
.modal-cl{width:32px;height:32px;border-radius:50%;border:none;background:var(--bg);
          display:flex;align-items:center;justify-content:center;cursor:pointer}
.modal-cl svg{width:16px;height:16px}
.mfg{margin-bottom:14px}
.mfg label{display:block;font-size:12.5px;font-weight:800;color:var(--dk);margin-bottom:6px}
.mfg input,.mfg select,.mfg textarea{
  width:100%;padding:10px 14px;border:2px solid #e8e8e8;border-radius:var(--rs);
  font-size:13px;font-weight:600;color:var(--dk);outline:none;transition:border-color .2s}
.mfg input:focus,.mfg select:focus,.mfg textarea:focus{border-color:var(--teal)}
.mfg textarea{resize:none;height:70px}
.mfg-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.modal-ft{display:flex;gap:10px;margin-top:20px}
.modal-ft button{flex:1;padding:12px;border-radius:14px;font-weight:800;
                 font-size:14px;border:none;cursor:pointer;transition:transform .18s}
.modal-ft button:hover{transform:scale(1.03)}
.btn-cancel{background:var(--bg);color:var(--md)}
.btn-save{background:var(--teal);color:white}
.btn-save-co{background:var(--coral);color:white}

/* ═══════════════════ TOAST ═══════════════════ */
.toast{
  position:fixed;bottom:24px;right:24px;z-index:999;
  background:#2D3436;color:white;padding:12px 20px;border-radius:14px;
  font-size:13px;font-weight:700;box-shadow:0 8px 24px rgba(0,0,0,.2);
  display:flex;align-items:center;gap:10px;
  transform:translateY(80px);opacity:0;
  transition:all .35s cubic-bezier(.4,0,.2,1);pointer-events:none;max-width:320px;
}
.toast.show{transform:translateY(0);opacity:1}
.toast.ok{border-left:4px solid var(--green)}
.toast.err{border-left:4px solid var(--coral)}
.toast svg{width:18px;height:18px;flex-shrink:0}

/* ═══════════════════ LOADING ═══════════════════ */
.spin{display:flex;align-items:center;justify-content:center;padding:40px;
      color:var(--md);font-weight:700;gap:12px;grid-column:1/-1}
.spin svg{animation:rotate 1s linear infinite;width:22px;height:22px}
@keyframes rotate{to{transform:rotate(360deg)}}

/* ═══════════════════ ANIMATIONS ═══════════════════ */
@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}

/* ═══════════════════ RESPONSIVE ═══════════════════ */
@media(max-width:1100px){
  .pg{grid-template-columns:1fr}
  .sidebar{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr))}
}
@media(max-width:900px){
  .nav-d{display:none}.hamburger{display:flex}
  header,.tabs-bar,.wrap,.perf-wrap,.padres-grid-wrap{padding-left:20px;padding-right:20px}
  .pg{padding:20px}
  .hero{padding:32px 24px 0;min-height:300px}
  .hero-text h1{font-size:32px}.paisaje{width:55%}
  .stats-row{grid-template-columns:1fr 1fr}
  .courses-grid,.feat-row,.cta-row,.mfg-row,.form-grid{grid-template-columns:1fr}
  .fg.full{grid-column:auto}
  .games-grid{grid-template-columns:repeat(auto-fill,minmax(220px,1fr))}
}
@media(max-width:600px){
  .hero{min-height:260px}.hero-text h1{font-size:26px}
  .hero-text p,.btn-gh{display:none}.paisaje{width:48%}
  .stats-row{grid-template-columns:1fr}.sidebar{grid-template-columns:1fr}
  .games-grid{grid-template-columns:1fr 1fr}
  .icon-btn.hm{display:none}
}
@media(max-width:400px){.games-grid{grid-template-columns:1fr}}
</style>
</head>
<body>

<!-- TOAST -->
<div class="toast" id="toast">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" id="toast-ic"><polyline points="20 6 9 17 4 12"/></svg>
  <span id="toast-msg"></span>
</div>

<!-- ══════════ HEADER ══════════ -->
<header>
  <div class="logo">Lo<span>o</span>no</div>
  <nav class="nav-d" id="navD">
    <button class="nl active" data-s="inicio"     onclick="go('inicio',this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>Inicio</button>
    <button class="nl" data-s="juegos"   onclick="go('juegos',this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M7 9v6M4 12h6"/><circle cx="17" cy="12" r="1" fill="currentColor"/><circle cx="20" cy="10" r="1" fill="currentColor"/></svg>Juegos</button>
    <button class="nl" data-s="tareas"   onclick="go('tareas',this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>Tareas</button>
    <button class="nl" data-s="logros"   onclick="go('logros',this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>Logros</button>
    <button class="nl" data-s="biblioteca" onclick="go('biblioteca',this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>Biblioteca</button>
    <button class="nl" data-s="perfil"   onclick="go('perfil',this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Perfil</button>
    <button class="nl" data-s="padres"   onclick="go('padres',this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>Padres</button>
  </nav>
  <div class="h-right">
    <button class="icon-btn nb hm"><svg viewBox="0 0 24 24" fill="none" stroke="#636E72" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg></button>
    <div class="av-mini" onclick="go('perfil',document.querySelector('[data-s=perfil]'))"><svg viewBox="0 0 24 24" fill="white"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
    <button class="hamburger" onclick="openDrawer()"><svg viewBox="0 0 24 24" fill="none" stroke="#636E72" stroke-width="2.5" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button>
  </div>
</header>

<!-- DRAWER MÓVIL -->
<div class="drawer" id="drawer">
  <div class="drawer-bg" onclick="closeDrawer()"></div>
  <div class="drawer-panel">
    <div class="drawer-head">
      <div class="logo">Lo<span>o</span>no</div>
      <button class="drawer-close" onclick="closeDrawer()"><svg viewBox="0 0 24 24" fill="none" stroke="#636E72" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <button class="mnl active" data-ms="inicio"    onclick="goM('inicio',this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>Inicio</button>
    <button class="mnl" data-ms="juegos"   onclick="goM('juegos',this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M7 9v6M4 12h6"/></svg>Juegos</button>
    <button class="mnl" data-ms="tareas"   onclick="goM('tareas',this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/></svg>Tareas</button>
    <button class="mnl" data-ms="logros"   onclick="goM('logros',this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>Logros</button>
    <button class="mnl" data-ms="biblioteca" onclick="goM('biblioteca',this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>Biblioteca</button>
    <button class="mnl" data-ms="perfil"   onclick="goM('perfil',this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Perfil</button>
    <button class="mnl" data-ms="padres"   onclick="goM('padres',this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>Padres</button>
  </div>
</div>

<!-- ══════════════════════════════════════════════
     SEC: INICIO
══════════════════════════════════════════════ -->
<div class="sec active" id="sec-inicio">
  <!-- HERO -->
  <section class="hero">
    <div class="paisaje"></div>
    <div class="hero-text">
      <div class="hero-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>¡Modo Aventura disponible!</div>
      <h1>¡Aprende<br><span class="cc">Jugando</span><br>con <span class="ct">Loono</span>!</h1>
      <p>Descubre aventuras educativas. Explora, aprende y diviértete cada día.</p>
      <div class="hero-btns">
        <button class="btn-pr" onclick="go('juegos',document.querySelector('[data-s=juegos]'))">
          <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>¡Explorar ahora!</button>
        <button class="btn-gh" onclick="go('juegos',document.querySelector('[data-s=juegos]'))">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M7 9v6M4 12h6"/></svg>Ver juegos</button>
      </div>
    </div>
    <svg class="hero-wave" viewBox="0 0 1440 50" preserveAspectRatio="none"><path d="M0,25 C360,50 1080,0 1440,25 L1440,50 L0,50 Z" fill="#E8FAF9"/></svg>
  </section>
  <!-- TABS -->
  <div class="tabs-bar">
    <button class="tab-btn active" onclick="go('inicio',document.querySelector('[data-s=inicio]'))"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>Cursos</button>
    <button class="tab-btn" onclick="go('juegos',document.querySelector('[data-s=juegos]'))"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M7 9v6M4 12h6"/></svg>Juegos</button>
    <button class="tab-btn" onclick="go('tareas',document.querySelector('[data-s=tareas]'))"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/></svg>Tareas</button>
    <button class="tab-btn" onclick="go('logros',document.querySelector('[data-s=logros]'))"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>Logros</button>
    <button class="tab-btn" onclick="go('biblioteca',document.querySelector('[data-s=biblioteca]'))"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>Biblioteca</button>
    <div class="tab-sp"></div>
    <button class="btn-ol" onclick="openGameModal()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>Nuevo juego</button>
  </div>
  <!-- MAIN GRID -->
  <div class="pg">
    <div>
      <!-- STATS -->
      <div class="stats-row">
        <div class="stat-card"><div class="stat-ic sic1"><svg viewBox="0 0 24 24" fill="none" stroke="#FF6B5E" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><div class="stat-info"><h3 id="sLec">—</h3><p>Lecciones completadas</p></div></div>
        <div class="stat-card"><div class="stat-ic sic2"><svg viewBox="0 0 24 24" fill="none" stroke="#4D96FF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></div><div class="stat-info"><h3 id="sEst">—</h3><p>Estrellas ganadas</p></div></div>
        <div class="stat-card"><div class="stat-ic sic3"><svg viewBox="0 0 24 24" fill="none" stroke="#6BCB77" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg></div><div class="stat-info"><h3 id="sRac">—</h3><p>Racha activa</p></div></div>
      </div>
      <!-- CURSOS -->
      <div class="sec-t"><svg viewBox="0 0 24 24" fill="none" stroke="var(--coral)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>Mis cursos</div>
      <div class="courses-grid" id="coursesGrid"><div class="spin"><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.5"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>Cargando...</div></div>
      <!-- FEATURES -->
      <div class="sec-t" style="margin-top:8px"><svg viewBox="0 0 24 24" fill="none" stroke="var(--purple)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>Actividades especiales</div>
      <div class="feat-row">
        <div class="feat-card" onclick="go('juegos',document.querySelector('[data-s=juegos]'))"><div class="feat-ic fc1"><svg viewBox="0 0 24 24" fill="none" stroke="#FF6B5E" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M7 9v6M4 12h6"/><circle cx="17" cy="12" r="1" fill="#FF6B5E"/><circle cx="20" cy="10" r="1" fill="#FF6B5E"/></svg></div><h5>Juegos</h5><p>Minijuegos educativos súper divertidos</p></div>
        <div class="feat-card" onclick="go('logros',document.querySelector('[data-s=logros]'))"><div class="feat-ic fc2"><svg viewBox="0 0 24 24" fill="none" stroke="#4D96FF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg></div><h5>Logros</h5><p>Completa retos y gana medallas especiales</p></div>
        <div class="feat-card" onclick="go('biblioteca',document.querySelector('[data-s=biblioteca]'))"><div class="feat-ic fc3"><svg viewBox="0 0 24 24" fill="none" stroke="#C77DFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg></div><h5>Biblioteca</h5><p>Descubre cuentos y libros de aprendizaje</p></div>
      </div>
      <div class="cta-row">
        <button class="cta-card org" onclick="go('juegos',document.querySelector('[data-s=juegos]'))"><div class="cta-iw"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg></div><div class="cta-tx"><h5>Lección Express</h5><p>¡Aprende algo nuevo en 5 minutos!</p></div></button>
        <button class="cta-card tea" onclick="toast('¡Próximamente! 👫','ok')"><div class="cta-iw"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg></div><div class="cta-tx"><h5>Aprender con amigos</h5><p>Invita a un amigo y aprendan juntos</p></div></button>
      </div>
    </div>
    <!-- SIDEBAR -->
    <aside class="sidebar">
      <div class="prof-card">
        <div class="av-lg"><svg viewBox="0 0 24 24" fill="white"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <h4 id="sbName">—</h4>
        <div class="prof-lv"><svg viewBox="0 0 24 24" fill="none" stroke="#FF9F43" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg><span id="sbNivel">Nivel —</span></div>
        <div class="xp-wrap"><div class="xp-bar" id="xpBar"></div></div>
        <div class="xp-lbl" id="xpLbl">— / — XP</div>
        <button class="btn-sm bs-co btn-full" onclick="go('perfil',document.querySelector('[data-s=perfil]'))"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Ver perfil</button>
      </div>
      <div class="cal-card">
        <div class="cal-hd">
          <h4><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Marzo 2026</h4>
          <div class="cal-nav"><button>‹</button><button>›</button></div>
        </div>
        <div class="cal-grid">
          <div class="dl">Lu</div><div class="dl">Ma</div><div class="dl">Mi</div><div class="dl">Ju</div><div class="dl">Vi</div><div class="dl">Sa</div><div class="dl">Do</div>
          <div class="day emp"></div><div class="day emp"></div><div class="day emp"></div><div class="day emp"></div><div class="day emp"></div><div class="day">1</div><div class="day">2</div>
          <div class="day ev">3</div><div class="day">4</div><div class="day ev">5</div><div class="day">6</div><div class="day ev">7</div><div class="day">8</div><div class="day">9</div>
          <div class="day">10</div><div class="day ev">11</div><div class="day">12</div><div class="day">13</div><div class="day ev">14</div><div class="day">15</div><div class="day">16</div>
          <div class="day">17</div><div class="day">18</div><div class="day ev">19</div><div class="day">20</div><div class="day">21</div><div class="day">22</div><div class="day">23</div>
          <div class="day">24</div><div class="day">25</div><div class="day today">26</div><div class="day">27</div><div class="day ev">28</div><div class="day">29</div><div class="day">30</div>
          <div class="day">31</div>
        </div>
      </div>
      <div class="ev-card">
        <div class="sec-t" style="font-size:16px;margin-bottom:10px"><svg viewBox="0 0 24 24" fill="none" stroke="var(--coral)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>Próximas actividades</div>
        <div class="ev-item" onclick="go('tareas',document.querySelector('[data-s=tareas]'))"><div class="ev-dot" style="background:var(--blue)"></div><div class="ev-info"><h6>Clase de Ciencias</h6><p>Hoy</p></div><div class="ev-time">10:00 AM</div></div>
        <div class="ev-item" onclick="go('tareas',document.querySelector('[data-s=tareas]'))"><div class="ev-dot" style="background:var(--coral)"></div><div class="ev-info"><h6>Reto Matemático</h6><p>Mañana</p></div><div class="ev-time">3:00 PM</div></div>
        <div class="ev-item" onclick="go('biblioteca',document.querySelector('[data-s=biblioteca]'))"><div class="ev-dot" style="background:var(--green)"></div><div class="ev-info"><h6>Lectura Grupal</h6><p>Miércoles</p></div><div class="ev-time">4:00 PM</div></div>
      </div>
    </aside>
  </div>
</div>

<!-- ══════════ SEC: JUEGOS ══════════ -->
<div class="sec" id="sec-juegos">
  <div class="wrap">
    <div class="sec-h">
      <div class="sec-t"><svg viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M7 9v6M4 12h6"/><circle cx="17" cy="12" r="1" fill="var(--blue)"/><circle cx="20" cy="10" r="1" fill="var(--blue)"/></svg>Mis Juegos</div>
      <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
        <div class="filter-chips">
          <button class="chip active" onclick="filterGames('todos',this)">Todos</button>
          <button class="chip" onclick="filterGames('matematicas',this)">Matemáticas</button>
          <button class="chip" onclick="filterGames('ciencias',this)">Ciencias</button>
          <button class="chip" onclick="filterGames('lenguaje',this)">Lenguaje</button>
          <button class="chip" onclick="filterGames('arte',this)">Arte</button>
        </div>
        <button class="btn-ol" onclick="openGameModal()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>Agregar juego</button>
      </div>
    </div>
    <div class="games-grid" id="gamesGrid"><div class="spin"><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.5"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>Cargando juegos...</div></div>
  </div>
</div>

<!-- ══════════ SEC: TAREAS ══════════ -->
<div class="sec" id="sec-tareas">
  <div class="wrap">
    <div class="sec-h">
      <div class="sec-t"><svg viewBox="0 0 24 24" fill="none" stroke="var(--orange)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>Mis Tareas</div>
      <button class="btn-ol" onclick="openTareaModal()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>Nueva tarea</button>
    </div>
    <div class="tareas-list" id="tareasList"><div class="spin"><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.5"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>Cargando...</div></div>
  </div>
</div>

<!-- ══════════ SEC: LOGROS ══════════ -->
<div class="sec" id="sec-logros">
  <div class="wrap">
    <div class="sec-t"><svg viewBox="0 0 24 24" fill="none" stroke="var(--yellow)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>Mis Logros</div>
    <div class="logros-grid" id="logrosGrid"><div class="spin"><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.5"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>Cargando...</div></div>
  </div>
</div>

<!-- ══════════ SEC: BIBLIOTECA ══════════ -->
<div class="sec" id="sec-biblioteca">
  <div class="wrap">
    <div class="sec-t"><svg viewBox="0 0 24 24" fill="none" stroke="var(--purple)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>Biblioteca</div>
    <div class="bib-grid" id="biblioGrid"><div class="spin"><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.5"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>Cargando...</div></div>
  </div>
</div>

<!-- ══════════ SEC: PERFIL ══════════ -->
<div class="sec" id="sec-perfil">
  <div class="perf-wrap">
    <div class="perf-card">
      <div class="perf-top">
        <div class="perf-av"><svg viewBox="0 0 24 24" fill="white"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="perf-inf">
          <h2 id="pNombreComp">—</h2>
          <p id="pRolDisp">—</p>
          <div class="perf-xp">
            <div class="xp-wrap"><div class="xp-bar" id="pXpBar"></div></div>
            <span id="pXpLbl" style="font-size:11px;font-weight:800;color:var(--md)">— XP</span>
          </div>
        </div>
      </div>
      <p class="fs-t">Información personal</p>
      <div class="form-grid">
        <div class="fg"><label>Nombre *</label><input type="text" id="pNom" placeholder="Tu nombre"></div>
        <div class="fg"><label>Apellido</label><input type="text" id="pApe" placeholder="Tu apellido"></div>
        <div class="fg"><label>Rol / Ocupación</label><input type="text" id="pRol" placeholder="Estudiante, Educador…"></div>
        <div class="fg"><label>WhatsApp</label><input type="tel" id="pWa" placeholder="+51 999 999 999"></div>
        <div class="fg"><label>Fecha de nacimiento</label><input type="date" id="pFn"></div>
        <div class="fg"><label>Avatar</label>
          <select id="pAv">
            <option value="nino1">🧒 Niño</option><option value="nina1">👧 Niña</option>
            <option value="robot">🤖 Robot</option><option value="astronauta">👨‍🚀 Astronauta</option>
            <option value="explorador">🧭 Explorador</option>
          </select>
        </div>
        <div class="fg full"><label>Bio</label><textarea id="pBio" placeholder="Cuéntanos algo sobre ti…"></textarea></div>
      </div>
      <div class="form-act">
        <button class="btn-sm" style="background:var(--bg);color:var(--md)" onclick="loadPerfil()">Cancelar</button>
        <button class="btn-sm bs-co" onclick="savePerfil()"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>Guardar cambios</button>
      </div>
      <div class="pwd-sec">
        <p class="fs-t">Seguridad</p>
        <div class="form-grid">
          <div class="fg"><label>Contraseña actual</label><input type="password" id="pwdA" placeholder="••••••••"></div>
          <div class="fg"></div>
          <div class="fg"><label>Nueva contraseña</label><input type="password" id="pwdN" placeholder="••••••••"></div>
          <div class="fg"><label>Confirmar</label><input type="password" id="pwdC" placeholder="••••••••"></div>
        </div>
        <div class="form-act">
          <button class="btn-sm bs-bl" onclick="changePwd()"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>Actualizar contraseña</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ══════════ SEC: PADRES ══════════ -->
<div class="sec" id="sec-padres">
  <div class="wrap">
    <div class="sec-t"><svg viewBox="0 0 24 24" fill="none" stroke="var(--coral)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>Zona de Padres</div>
    <div class="padres-grid">
      <div class="pad-card"><div class="pad-ic" style="background:#FFF0EE"><svg viewBox="0 0 24 24" fill="none" stroke="#FF6B5E" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg></div><h4>Progreso del estudiante</h4><p>Revisa avance en cursos, lecciones y estadísticas de aprendizaje.</p><button class="btn-sm bs-co" onclick="go('inicio',document.querySelector('[data-s=inicio]'))"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>Ver resumen</button></div>
      <div class="pad-card"><div class="pad-ic" style="background:#EEF4FF"><svg viewBox="0 0 24 24" fill="none" stroke="#4D96FF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><h4>Control de tiempo</h4><p>Configura límites de uso diario y horarios de estudio.</p><button class="btn-sm bs-bl" onclick="toast('Próximamente ⏱️','ok')"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Configurar</button></div>
      <div class="pad-card"><div class="pad-ic" style="background:#F3ECFF"><svg viewBox="0 0 24 24" fill="none" stroke="#C77DFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg></div><h4>Notificaciones</h4><p>Recibe alertas sobre logros, actividades pendientes y progreso semanal.</p><button class="btn-sm bs-pu" onclick="toast('Notificaciones activadas 🔔','ok')"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Activar</button></div>
      <div class="pad-card"><div class="pad-ic" style="background:#F0FFF4"><svg viewBox="0 0 24 24" fill="none" stroke="#6BCB77" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg></div><h4>Modo familiar</h4><p>Agrega perfiles de más hijos y organiza el aprendizaje familiar.</p><button class="btn-sm bs-gr" onclick="toast('Próximamente 👨‍👩‍👧‍👦','ok')"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Gestionar</button></div>
    </div>
  </div>
</div>

<!-- ══════════ MODAL: JUEGO ══════════ -->
<div class="modal-ov" id="gameModal">
  <div class="modal">
    <div class="modal-hd"><h3 id="gmTitle">➕ Agregar juego</h3><button class="modal-cl" onclick="closeGameModal()"><svg viewBox="0 0 24 24" fill="none" stroke="#636E72" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <input type="hidden" id="gmId">
    <div class="mfg"><label>Nombre del juego *</label><input type="text" id="gmNom" placeholder="Ej: Suma Aventura" maxlength="80"></div>
    <div class="mfg"><label>Enlace (URL) *</label><input type="url" id="gmUrl" placeholder="https://mi-juego.com/play"></div>
    <div class="mfg"><label>Descripción</label><textarea id="gmDesc" placeholder="¿De qué trata el juego?"></textarea></div>
    <div class="mfg-row">
      <div class="mfg"><label>Categoría</label>
        <select id="gmCat">
          <option value="matematicas">Matemáticas</option><option value="ciencias">Ciencias</option>
          <option value="lenguaje">Lenguaje</option><option value="arte">Arte</option><option value="otro">Otro</option>
        </select>
      </div>
      <div class="mfg"><label>Color de tarjeta</label>
        <select id="gmColor">
          <option value="coral">🔴 Coral</option><option value="blue">🔵 Azul</option>
          <option value="teal">🟢 Verde agua</option><option value="purple">🟣 Morado</option><option value="yellow">🟡 Amarillo</option>
        </select>
      </div>
    </div>
    <div class="mfg"><label>Etiqueta / Badge <span style="font-weight:400;color:var(--md)">(opcional)</span></label><input type="text" id="gmBadge" placeholder="Nuevo, Popular…" maxlength="20"></div>
    <div class="modal-ft">
      <button class="btn-cancel" onclick="closeGameModal()">Cancelar</button>
      <button class="btn-save" onclick="saveGame()">Guardar juego</button>
    </div>
  </div>
</div>

<!-- ══════════ MODAL: TAREA ══════════ -->
<div class="modal-ov" id="tareaModal">
  <div class="modal">
    <div class="modal-hd"><h3>✏️ Nueva tarea</h3><button class="modal-cl" onclick="closeTareaModal()"><svg viewBox="0 0 24 24" fill="none" stroke="#636E72" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <div class="mfg"><label>Título *</label><input type="text" id="taTit" placeholder="Ej: Resolver ejercicios de suma"></div>
    <div class="mfg"><label>Materia</label><input type="text" id="taMat" placeholder="Ej: Matemáticas · Lección 5"></div>
    <div class="mfg"><label>Fecha límite</label><input type="date" id="taFec"></div>
    <div class="modal-ft">
      <button class="btn-cancel" onclick="closeTareaModal()">Cancelar</button>
      <button class="btn-save" onclick="saveTarea()">Agregar tarea</button>
    </div>
  </div>
</div>

<script>
// ══════════════════════════════════════════════════
//  CONFIGURACIÓN DE APIs
// ══════════════════════════════════════════════════
const A = {
  juegos: 'api/juegos.php',
  cursos: 'api/cursos.php',
  datos:  'api/datos.php',
};

// Mapa de colores para juegos
const GC = {
  coral:  {bg:'linear-gradient(135deg,#FF6B5E,#FF9B75)',btn:'#FF6B5E',txt:'white'},
  blue:   {bg:'linear-gradient(135deg,#4D96FF,#5ECDFF)',btn:'#4D96FF',txt:'white'},
  teal:   {bg:'linear-gradient(135deg,#4ECDC4,#26C6BA)',btn:'#4ECDC4',txt:'white'},
  purple: {bg:'linear-gradient(135deg,#C77DFF,#A855F7)',btn:'#C77DFF',txt:'white'},
  yellow: {bg:'linear-gradient(135deg,#FFD93D,#FFB800)',btn:'#FFD93D',txt:'#5a4000'},
};

// Íconos SVG por color de curso
const CI = {
  coral:`<svg viewBox="0 0 24 24" fill="none" stroke="#FF6B5E" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>`,
  blue: `<svg viewBox="0 0 24 24" fill="none" stroke="#4D96FF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>`,
  yellow:`<svg viewBox="0 0 24 24" fill="none" stroke="#e6a800" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><circle cx="11" cy="11" r="2"/></svg>`,
  green:`<svg viewBox="0 0 24 24" fill="none" stroke="#41B54A" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>`,
};

const CL = {matematicas:'Matemáticas',ciencias:'Ciencias',lenguaje:'Lenguaje',arte:'Arte',otro:'Otro'};
const CB = {coral:'bs-co',blue:'bs-bl',yellow:'bs-ye',green:'bs-gr'};

let gFilter='todos', gEditMode=false;

// ══════════════════════════════════════════════════
//  TOAST
// ══════════════════════════════════════════════════
let _tt;
function toast(msg,type='ok'){
  const el=document.getElementById('toast'),ic=document.getElementById('toast-ic');
  el.className='toast show '+type;
  document.getElementById('toast-msg').textContent=msg;
  ic.innerHTML=type==='ok'
    ?'<polyline points="20 6 9 17 4 12"/>'
    :'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>';
  clearTimeout(_tt);_tt=setTimeout(()=>el.classList.remove('show'),3200);
}

// ══════════════════════════════════════════════════
//  FETCH
// ══════════════════════════════════════════════════
async function api(url,data=null){
  const r=await fetch(url,data?{method:'POST',body:new URLSearchParams(data)}:{});
  return r.json();
}

// ══════════════════════════════════════════════════
//  NAVEGACIÓN
// ══════════════════════════════════════════════════
function go(sec,el){
  document.querySelectorAll('.sec').forEach(s=>s.classList.remove('active'));
  document.getElementById('sec-'+sec).classList.add('active');
  document.querySelectorAll('.nl').forEach(n=>n.classList.remove('active'));
  const t=document.querySelector(`.nl[data-s="${sec}"]`);
  if(t)t.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  ({juegos:loadGames,tareas:loadTareas,logros:loadLogros,biblioteca:loadBiblio,perfil:loadPerfil}[sec]||(() => {}))();
}
function goM(sec,el){
  closeDrawer();
  go(sec,el);
  document.querySelectorAll('.mnl').forEach(n=>n.classList.remove('active'));
  el.classList.add('active');
}
function openDrawer(){document.getElementById('drawer').classList.add('open')}
function closeDrawer(){document.getElementById('drawer').classList.remove('open')}

// ══════════════════════════════════════════════════
//  ESTADÍSTICAS
// ══════════════════════════════════════════════════
async function loadStats(){
  const r=await api(A.datos+'?action=stats');
  if(!r.ok)return;
  const d=r.data;
  document.getElementById('sLec').textContent=d.lecciones_completadas;
  document.getElementById('sEst').textContent=Number(d.estrellas_ganadas).toLocaleString('es');
  document.getElementById('sRac').textContent=d.racha_dias+' días';
  document.getElementById('sbName').textContent=(d.nombre||'')+' '+(d.apellido||'');
  document.getElementById('sbNivel').textContent='Explorador Nivel '+d.nivel;
  document.getElementById('xpLbl').textContent=d.xp_actual+' / '+d.xp_meta+' XP';
  setTimeout(()=>{const p=Math.round(d.xp_actual/d.xp_meta*100);document.getElementById('xpBar').style.width=p+'%';},400);
}

// ══════════════════════════════════════════════════
//  CURSOS
// ══════════════════════════════════════════════════
async function loadCourses(){
  const r=await api(A.cursos+'?action=list');
  if(!r.ok)return;
  const g=document.getElementById('coursesGrid');
  if(!r.data.length){g.innerHTML='<p style="padding:24px;color:var(--md)">No hay cursos disponibles.</p>';return;}
  g.innerHTML=r.data.map((c,i)=>{
    const ic=CI[c.icono_color]||CI.coral;
    const bc=CB[c.icono_color]||'bs-co';
    const bt=c.icono_color==='yellow'?'#5a4000':'white';
    return`<div class="cc cc-${c.icono_color}" style="animation-delay:${i*.08}s">
      <div class="cc-ic ci-${c.icono_color}">${ic}</div>
      <h4>${esc(c.titulo)}</h4>
      <p>${esc(c.descripcion)}</p>
      <div class="pb-wrap"><div class="pb pb-${c.icono_color}" id="pb${c.id}" data-w="${c.porcentaje}"></div></div>
      <div class="pb-pct" id="pct${c.id}">${c.porcentaje}% — ${c.lecciones_hechas}/${c.total_lecciones} lecciones</div>
      <div class="stepper">
        <button class="stp-m" onclick="step(${c.id},${c.lecciones_hechas},${c.total_lecciones},-1)">−</button>
        <span class="stp-val" id="sv${c.id}">${c.lecciones_hechas} / ${c.total_lecciones}</span>
        <button class="stp-p" onclick="step(${c.id},${c.lecciones_hechas},${c.total_lecciones},+1)">+</button>
      </div>
      <button class="btn-sm ${bc}" onclick="toast('Abriendo ${esc(c.titulo)} 📚','ok')">
        <svg viewBox="0 0 24 24" fill="none" stroke="${bt}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>Continuar</button>
    </div>`;
  }).join('');
  // Animar barras
  setTimeout(()=>{
    document.querySelectorAll('.pb[data-w]').forEach(b=>{
      b.style.transition='width 1.1s cubic-bezier(.4,0,.2,1)';
      b.style.width=b.dataset.w+'%';
    });
  },200);
}

async function step(cid,actual,total,delta){
  const nuevo=Math.max(0,Math.min(total,actual+delta));
  const r=await api(A.cursos+'?action=update',{curso_id:cid,lecciones_hechas:nuevo});
  if(!r.ok){toast(r.error||'Error','err');return;}
  // Actualizar UI
  document.getElementById('sv'+cid).textContent=nuevo+' / '+total;
  document.getElementById('pct'+cid).textContent=r.porcentaje+'% — '+nuevo+'/'+total+' lecciones';
  const bar=document.getElementById('pb'+cid);
  bar.style.width=r.porcentaje+'%';bar.dataset.w=r.porcentaje;
  // Reasignar onclick con nuevo valor actual
  const btns=document.querySelectorAll(`button[onclick*="step(${cid},"]`);
  btns.forEach(b=>{const oc=b.getAttribute('onclick');
    b.setAttribute('onclick',oc.replace(/step\(\d+,\d+,\d+,/,`step(${cid},${nuevo},${total},`));});
  toast('✅ Progreso guardado','ok');
  loadStats();
}

// ══════════════════════════════════════════════════
//  JUEGOS
// ══════════════════════════════════════════════════
async function loadGames(cat){
  if(cat!==undefined)gFilter=cat;
  const g=document.getElementById('gamesGrid');
  g.innerHTML=`<div class="spin"><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.5"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>Cargando...</div>`;
  const url=A.juegos+'?action=list'+(gFilter!=='todos'?'&cat='+gFilter:'');
  const r=await api(url);
  if(!r.ok){g.innerHTML='<p style="padding:24px;color:var(--md)">Error al cargar.</p>';return;}

  let html=r.data.map((gm,i)=>{
    const c=GC[gm.color]||GC.teal;
    const favOn=gm.favorito=='1';
    return`<div class="game-card" style="animation-delay:${i*.06}s" id="gcard${gm.id}">
      <div class="gc-thumb" style="background:${c.bg}">
        ${gm.badge?`<div class="gc-badge">${esc(gm.badge)}</div>`:''}
        <div class="gc-overlay"></div>
        <button class="gc-play" onclick="openGame(${gm.id},'${esc(gm.titulo)}','${esc(gm.url)}')">
          <svg viewBox="0 0 24 24" fill="${c.btn}" stroke="${c.btn}" stroke-width="1.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        </button>
      </div>
      <div class="gc-body">
        <h4>${esc(gm.titulo)}</h4>
        <p>${esc(gm.descripcion||'')}</p>
        <div class="gc-meta">
          <span class="gc-tag">${CL[gm.categoria]||gm.categoria}</span>
          <div class="gc-stars">${[1,2,3,4,5].map(s=>`<svg viewBox="0 0 24 24" fill="${s<=4?'#FFD93D':'#e0e0e0'}" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`).join('')}</div>
        </div>
      </div>
      <div class="gc-foot">
        <button class="btn-play" style="background:${c.btn};color:${c.txt}"
          onclick="openGame(${gm.id},'${esc(gm.titulo)}','${esc(gm.url)}')">
          <svg viewBox="0 0 24 24" fill="none" stroke="${c.txt}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>Jugar
        </button>
        <button class="btn-ico ${favOn?'fav-on':''}" title="${favOn?'Quitar favorito':'Agregar a favoritos'}"
          onclick="toggleFav(${gm.id},this)">
          <svg viewBox="0 0 24 24" fill="${favOn?'white':'none'}" stroke="${favOn?'white':'#636E72'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
        </button>
        <button class="btn-ico edit" title="Editar" onclick="editGame(${gm.id})">
          <svg viewBox="0 0 24 24" fill="none" stroke="#4D96FF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </button>
        <button class="btn-ico del" title="Eliminar" onclick="deleteGame(${gm.id})">
          <svg viewBox="0 0 24 24" fill="none" stroke="#FF6B5E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>
        </button>
      </div>
    </div>`;
  }).join('');

  html+=`<div class="add-card" onclick="openGameModal()">
    <div class="add-ic"><svg viewBox="0 0 24 24" fill="none" stroke="var(--teal)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></div>
    <h4>Agregar juego</h4><p>Pega el link de tu juego favorito y agrégalo a tu colección</p>
  </div>`;
  g.innerHTML=html;
}

function filterGames(cat,el){
  document.querySelectorAll('.chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');loadGames(cat);
}

function openGame(id,titulo,url){
  if(confirm(`¿Abrir "${titulo}"?\n\n🔗 ${url}`))window.open(url,'_blank');
}

async function toggleFav(id,btn){
  const r=await api(A.juegos+'?action=toggle',{id});
  if(!r.ok)return;
  const on=r.favorito===1;
  btn.classList.toggle('fav-on',on);
  const sv=btn.querySelector('svg');
  sv.setAttribute('fill',on?'white':'none');sv.setAttribute('stroke',on?'white':'#636E72');
  btn.title=on?'Quitar favorito':'Agregar a favoritos';
  toast(on?'⭐ Añadido a favoritos':'Quitado de favoritos','ok');
}

async function deleteGame(id){
  if(!confirm('¿Eliminar este juego?'))return;
  const r=await api(A.juegos+'?action=delete',{id});
  if(r.ok){toast('Juego eliminado','ok');loadGames();}
  else toast(r.error||'Error','err');
}

// Modal juego
function openGameModal(){
  gEditMode=false;
  document.getElementById('gmTitle').textContent='➕ Agregar juego';
  document.getElementById('gmId').value='';
  ['gmNom','gmUrl','gmDesc','gmBadge'].forEach(i=>document.getElementById(i).value='');
  document.getElementById('gmCat').value='matematicas';
  document.getElementById('gmColor').value='teal';
  document.getElementById('gameModal').classList.add('open');
  setTimeout(()=>document.getElementById('gmNom').focus(),100);
}

function editGame(id){
  api(A.juegos+'?action=list').then(r=>{
    if(!r.ok)return;
    const gm=r.data.find(x=>x.id==id);if(!gm)return;
    gEditMode=true;
    document.getElementById('gmTitle').textContent='✏️ Editar juego';
    document.getElementById('gmId').value=gm.id;
    document.getElementById('gmNom').value=gm.titulo;
    document.getElementById('gmUrl').value=gm.url;
    document.getElementById('gmDesc').value=gm.descripcion||'';
    document.getElementById('gmCat').value=gm.categoria;
    document.getElementById('gmColor').value=gm.color;
    document.getElementById('gmBadge').value=gm.badge||'';
    document.getElementById('gameModal').classList.add('open');
  });
}

function closeGameModal(){document.getElementById('gameModal').classList.remove('open')}

async function saveGame(){
  const titulo=document.getElementById('gmNom').value.trim();
  const url=document.getElementById('gmUrl').value.trim();
  if(!titulo){toast('El nombre es obligatorio','err');document.getElementById('gmNom').focus();return;}
  if(!url){toast('El enlace es obligatorio','err');document.getElementById('gmUrl').focus();return;}
  // Validar URL
  try{new URL(url);}catch{toast('La URL no es válida. Incluye https://','err');return;}

  const data={titulo,url,
    descripcion:document.getElementById('gmDesc').value.trim(),
    categoria:document.getElementById('gmCat').value,
    color:document.getElementById('gmColor').value,
    badge:document.getElementById('gmBadge').value.trim()};

  let r;
  if(gEditMode){data.action='edit';data.id=document.getElementById('gmId').value;r=await api(A.juegos+'?action=edit',data);}
  else r=await api(A.juegos+'?action=add',data);

  if(r.ok){toast(gEditMode?'✅ Juego actualizado':'🎮 Juego agregado','ok');closeGameModal();loadGames();}
  else toast(r.error||'Error al guardar','err');
}

// ══════════════════════════════════════════════════
//  TAREAS
// ══════════════════════════════════════════════════
async function loadTareas(){
  const r=await api(A.datos+'?action=tareas_list');
  if(!r.ok)return;
  const list=document.getElementById('tareasList');
  if(!r.data.length){list.innerHTML='<p style="padding:24px;color:var(--md)">¡Sin tareas pendientes! 🎉</p>';return;}
  list.innerHTML=r.data.map((t,i)=>{
    const done=t.completada=='1';
    let fStr='';
    if(t.fecha_limite){
      const d=new Date(t.fecha_limite+'T12:00:00');
      fStr=d.toLocaleDateString('es',{day:'numeric',month:'short'});
    }
    return`<div class="ta-item ${done?'done-i':''}" style="animation-delay:${i*.06}s" id="ti${t.id}">
      <div class="ta-chk ${done?'done':''}" onclick="toggleTarea(${t.id},this)">
        <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
      </div>
      <div class="ta-info"><h5>${esc(t.titulo)}</h5><p>${esc(t.materia||'')}</p></div>
      <div class="ta-date">${fStr}</div>
      <button class="ta-del" onclick="deleteTarea(${t.id})" title="Eliminar">
        <svg viewBox="0 0 24 24" fill="none" stroke="#FF6B5E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>
      </button>
    </div>`;
  }).join('');
}

async function toggleTarea(id,btn){
  const r=await api(A.datos+'?action=tarea_toggle',{id});
  if(!r.ok)return;
  const done=r.completada===1;
  btn.classList.toggle('done',done);
  const item=document.getElementById('ti'+id);
  item.classList.toggle('done-i',done);
  if(done)toast('✅ ¡Tarea completada! +5⭐','ok');
  loadStats();
}

async function deleteTarea(id){
  if(!confirm('¿Eliminar esta tarea?'))return;
  const r=await api(A.datos+'?action=tarea_delete',{id});
  if(r.ok){toast('Tarea eliminada','ok');loadTareas();}
}

function openTareaModal(){
  document.getElementById('tareaModal').classList.add('open');
  ['taTit','taMat','taFec'].forEach(i=>document.getElementById(i).value='');
  setTimeout(()=>document.getElementById('taTit').focus(),100);
}
function closeTareaModal(){document.getElementById('tareaModal').classList.remove('open')}

async function saveTarea(){
  const titulo=document.getElementById('taTit').value.trim();
  if(!titulo){toast('El título es obligatorio','err');document.getElementById('taTit').focus();return;}
  const r=await api(A.datos+'?action=tarea_add',{
    titulo,materia:document.getElementById('taMat').value.trim(),
    fecha_limite:document.getElementById('taFec').value});
  if(r.ok){toast('📝 Tarea agregada','ok');closeTareaModal();loadTareas();}
  else toast(r.error||'Error','err');
}

// ══════════════════════════════════════════════════
//  LOGROS
// ══════════════════════════════════════════════════
async function loadLogros(){
  const r=await api(A.datos+'?action=logros');
  if(!r.ok)return;
  document.getElementById('logrosGrid').innerHTML=r.data.map((l,i)=>`
    <div class="lo-card ${l.desbloqueado=='1'?'':'locked'}" style="animation-delay:${i*.05}s">
      <div class="lo-ic" style="background:${l.color_fondo}">${l.emoji}</div>
      <h5>${esc(l.titulo)}</h5><p>${esc(l.descripcion)}</p>
      ${l.desbloqueado=='1'?'':'<p style="font-size:11px;margin-top:6px;color:#b2bec3">🔒 Bloqueado</p>'}
      ${l.desbloqueado=='1'&&isRecent(l.desbloqueado_en)?'<span class="badge-new">¡Nuevo!</span>':''}
    </div>`).join('');
}

function isRecent(d){
  if(!d)return false;
  return(Date.now()-new Date(d).getTime())<7*864e5;
}

// ══════════════════════════════════════════════════
//  BIBLIOTECA
// ══════════════════════════════════════════════════
async function loadBiblio(){
  const r=await api(A.datos+'?action=biblioteca');
  if(!r.ok)return;
  document.getElementById('biblioGrid').innerHTML=r.data.map((b,i)=>`
    <div class="bk-card" style="animation-delay:${i*.06}s" onclick="toggleBook(${b.id},this)">
      <div class="bk-cover" style="background:${b.color_fondo}">
        ${b.emoji}${b.leido=='1'?'<div class="bk-read">✓ Leído</div>':''}
      </div>
      <div class="bk-info"><h5>${esc(b.titulo)}</h5><p>${esc(b.materia||'')} · ${esc(b.nivel_texto||'')}</p></div>
    </div>`).join('');
}

async function toggleBook(id,card){
  const r=await api(A.datos+'?action=libro_toggle',{id});
  if(!r.ok)return;
  const cover=card.querySelector('.bk-cover');
  let badge=cover.querySelector('.bk-read');
  if(r.leido===1){
    if(!badge){badge=document.createElement('div');badge.className='bk-read';cover.appendChild(badge);}
    badge.textContent='✓ Leído';toast('📖 ¡Libro leído! +10⭐','ok');
  }else{if(badge)badge.remove();toast('Libro desmarcado','ok');}
  loadStats();
}

// ══════════════════════════════════════════════════
//  PERFIL
// ══════════════════════════════════════════════════
async function loadPerfil(){
  const r=await api(A.datos+'?action=perfil_get');
  if(!r.ok)return;
  const p=r.data;
  document.getElementById('pNombreComp').textContent=(p.nombre||'')+' '+(p.apellido||'');
  document.getElementById('pRolDisp').textContent=p.rol||'Sin rol asignado';
  document.getElementById('pNom').value=p.nombre||'';
  document.getElementById('pApe').value=p.apellido||'';
  document.getElementById('pRol').value=p.rol||'';
  document.getElementById('pWa').value=p.whatsapp||'';
  document.getElementById('pFn').value=p.fecha_nacimiento||'';
  document.getElementById('pAv').value=p.nombre_avatar||'nino1';
  document.getElementById('pBio').value=p.bio||'';
  const pct=p.xp_meta>0?Math.round(p.xp_actual/p.xp_meta*100):0;
  document.getElementById('pXpLbl').textContent=p.xp_actual+' / '+p.xp_meta+' XP';
  setTimeout(()=>{document.getElementById('pXpBar').style.width=pct+'%';},300);
}

async function savePerfil(){
  const r=await api(A.datos+'?action=perfil_update',{
    nombre:document.getElementById('pNom').value.trim(),
    apellido:document.getElementById('pApe').value.trim(),
    rol:document.getElementById('pRol').value.trim(),
    whatsapp:document.getElementById('pWa').value.trim(),
    fecha_nacimiento:document.getElementById('pFn').value,
    nombre_avatar:document.getElementById('pAv').value,
    bio:document.getElementById('pBio').value.trim()
  });
  if(r.ok){toast('✅ Perfil actualizado','ok');loadPerfil();loadStats();}
  else toast(r.error||'Error','err');
}

async function changePwd(){
  const r=await api(A.datos+'?action=change_password',{
    password_actual:document.getElementById('pwdA').value,
    password_nueva:document.getElementById('pwdN').value,
    password_confirmar:document.getElementById('pwdC').value
  });
  if(r.ok){
    toast('🔒 Contraseña actualizada','ok');
    ['pwdA','pwdN','pwdC'].forEach(i=>document.getElementById(i).value='');
  }else toast(r.error||'Error','err');
}

// ══════════════════════════════════════════════════
//  UTIL
// ══════════════════════════════════════════════════
function esc(s){
  return String(s||'')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

// ══════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════
window.addEventListener('load',()=>{
  loadStats();
  loadCourses();
});
</script>
</body>
</html>
